// content.js — injected into perplexity.ai
(function () {
  if (document.getElementById('_pu_fab')) return;

  var PRO_MAX     = 200;
  var ONE_HOUR_MS = 60 * 60 * 1000;
  var MAX_SEG_GAP = 6 * 60 * 1000; // gaps > 6 min split the graph line

  // ─── STYLES ──────────────────────────────────────────────────────────────────
  var style = document.createElement('style');
  style.textContent = [
    '@keyframes _pu_in{from{opacity:0;transform:translateY(8px) scale(.97)}to{opacity:1;transform:translateY(0) scale(1)}}',
    '@keyframes _pu_spin{to{transform:rotate(360deg)}}',
    '@keyframes _pu_pulse{0%,100%{opacity:1}50%{opacity:.25}}',
    '@keyframes _pu_up{from{opacity:0;transform:translateY(5px)}to{opacity:1;transform:translateY(0)}}',
    '@keyframes _pu_fadein{from{opacity:0}to{opacity:1}}',

    // ── Dark defaults ──────────────────────────────────────────────────────────
    '#_pu_panel,#_pu_fab{',
      '--bg:#0f0f0f;--surf:#161616;--surf2:#1c1c1c;',
      '--bdr:rgba(255,255,255,.07);--bdr-hi:rgba(255,255,255,.13);',
      '--hdr:rgba(255,255,255,.015);--sep:rgba(255,255,255,.05);',
      '--tx:rgba(255,255,255,.88);--sub:rgba(255,255,255,.45);',
      '--mu:rgba(255,255,255,.25);--mu2:rgba(255,255,255,.12);',
      '--sh:0 12px 48px rgba(0,0,0,.7);',
      '--sp1:rgba(255,255,255,.08);--sp2:rgba(255,255,255,.4);',
      '--red:#f87171;--amber:#fbbf24;--grn:#34d399;',
    '}',

    // ── System light override ──────────────────────────────────────────────────
    '@media(prefers-color-scheme:light){',
      '#_pu_panel:not(._fl):not(._fd),#_pu_fab:not(._fl):not(._fd){',
        '--bg:#fff;--surf:#f5f4f2;--surf2:#eceae6;',
        '--bdr:rgba(0,0,0,.07);--bdr-hi:rgba(0,0,0,.14);',
        '--hdr:rgba(0,0,0,.025);--sep:rgba(0,0,0,.07);',
        '--tx:#111;--sub:rgba(0,0,0,.55);--mu:rgba(0,0,0,.38);--mu2:rgba(0,0,0,.18);',
        '--sh:0 4px 20px rgba(0,0,0,.1),0 1px 4px rgba(0,0,0,.06);',
        '--sp1:rgba(0,0,0,.08);--sp2:rgba(0,0,0,.4);',
        '--red:#dc2626;--amber:#d97706;--grn:#0ea66e;',
      '}',
    '}',
    // ── Force-light class ─────────────────────────────────────────────────────
    '#_pu_panel._fl,#_pu_fab._fl{',
      '--bg:#fff;--surf:#f5f4f2;--surf2:#eceae6;',
      '--bdr:rgba(0,0,0,.07);--bdr-hi:rgba(0,0,0,.14);',
      '--hdr:rgba(0,0,0,.025);--sep:rgba(0,0,0,.07);',
      '--tx:#111;--sub:rgba(0,0,0,.55);--mu:rgba(0,0,0,.38);--mu2:rgba(0,0,0,.18);',
      '--sh:0 4px 20px rgba(0,0,0,.1),0 1px 4px rgba(0,0,0,.06);',
      '--sp1:rgba(0,0,0,.08);--sp2:rgba(0,0,0,.4);',
      '--red:#dc2626;--amber:#d97706;--grn:#0ea66e;',
    '}',
    // ── Force-dark class ──────────────────────────────────────────────────────
    '#_pu_panel._fd,#_pu_fab._fd{',
      '--bg:#0f0f0f;--surf:#161616;--surf2:#1c1c1c;',
      '--bdr:rgba(255,255,255,.07);--bdr-hi:rgba(255,255,255,.13);',
      '--hdr:rgba(255,255,255,.015);--sep:rgba(255,255,255,.05);',
      '--tx:rgba(255,255,255,.88);--sub:rgba(255,255,255,.45);',
      '--mu:rgba(255,255,255,.25);--mu2:rgba(255,255,255,.12);',
      '--sh:0 12px 48px rgba(0,0,0,.7);',
      '--sp1:rgba(255,255,255,.08);--sp2:rgba(255,255,255,.4);',
      '--red:#f87171;--amber:#fbbf24;--grn:#34d399;',
    '}',

    // ── FAB ───────────────────────────────────────────────────────────────────
    '#_pu_fab{position:fixed;bottom:24px;right:24px;z-index:2147483647;width:40px;height:40px;border-radius:50%;border:1px solid var(--bdr);cursor:pointer;background:var(--surf);box-shadow:0 2px 10px rgba(0,0,0,.25);display:flex;align-items:center;justify-content:center;transition:all .2s;}',
    '#_pu_fab:hover{background:var(--surf2);border-color:var(--bdr-hi);transform:scale(1.06);}',
    '#_pu_fab svg{color:var(--sub);}',
    '#_pu_fab._pu_on{border-color:rgba(52,211,153,.4);box-shadow:0 0 14px rgba(52,211,153,.18);}',
    '#_pu_fab._pu_warn{border-color:rgba(251,191,36,.45);}',
    '#_pu_fab._pu_low{border-color:rgba(248,113,113,.55);}',

    // ── Panel ─────────────────────────────────────────────────────────────────
    '#_pu_panel{position:fixed;bottom:72px;right:24px;z-index:2147483646;width:380px;background:var(--bg);border:1px solid var(--bdr);border-radius:14px;box-shadow:var(--sh);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Inter,sans-serif;overflow:hidden;animation:_pu_in .18s cubic-bezier(.2,.8,.4,1) both;transition:width .22s cubic-bezier(.2,.8,.4,1);}',
    '#_pu_panel._pu_wide{width:520px;}',

    // ── Header ────────────────────────────────────────────────────────────────
    '#_pu_ph{padding:11px 12px 9px;display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid var(--sep);background:var(--hdr);}',
    '._pu_hrow{display:flex;align-items:center;gap:6px;}',
    '._pu_dot{width:5px;height:5px;border-radius:50%;background:var(--mu2);flex-shrink:0;transition:all .4s;}',
    '._pu_dot._live{background:var(--grn);box-shadow:0 0 5px var(--grn);animation:_pu_pulse 3s infinite;}',
    '._pu_dot._err{background:var(--red);}',
    '._pu_title{font-size:.95rem;font-weight:600;color:var(--tx);letter-spacing:-.02em;}',
    '._pu_title em{font-style:normal;color:var(--grn);}',
    '._pu_ts{font-size:.72rem;color:var(--mu);font-variant-numeric:tabular-nums;}',
    '._pu_rbtn{background:transparent;border:none;color:var(--mu);width:28px;height:28px;border-radius:6px;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:all .15s;padding:0;}',
    '._pu_rbtn:hover{background:var(--bdr);color:var(--sub);}',
    '._pu_rbtn:disabled{opacity:.25;cursor:not-allowed;}',

    // ── Theme toggle ──────────────────────────────────────────────────────────
    '._pu_thmenu{position:relative;}',
    '._pu_thdrop{display:none;position:absolute;top:28px;right:0;background:var(--bg);border:1px solid var(--bdr);border-radius:8px;box-shadow:var(--sh);padding:4px;z-index:10;white-space:nowrap;min-width:90px;}',
    '._pu_thmenu._open ._pu_thdrop{display:block;animation:_pu_fadein .12s ease both;}',
    '._pu_thopt{display:flex;align-items:center;gap:6px;padding:5px 8px;border-radius:5px;font-size:.6rem;color:var(--sub);cursor:pointer;transition:background .12s;}',
    '._pu_thopt:hover{background:var(--surf2);}',
    '._pu_thopt._act{color:var(--grn);font-weight:600;}',

    // ── Body / Spinner ────────────────────────────────────────────────────────
    '#_pu_pb{padding:10px;}',
    '._pu_sp{width:15px;height:15px;border:1.5px solid var(--sp1);border-top-color:var(--sp2);border-radius:50%;animation:_pu_spin .65s linear infinite;}',

    // ── Compact 2×2 grid ──────────────────────────────────────────────────────
    '._pu_grid{display:grid;grid-template-columns:1fr 1fr;gap:7px;}',
    '._pu_card{background:var(--surf);border:1px solid var(--bdr);border-radius:10px;padding:13px 13px 30px;position:relative;overflow:hidden;opacity:0;animation:_pu_up .22s ease both;transition:border-color .15s,background .15s;cursor:pointer;}',
    '._pu_card:hover{background:var(--surf2);border-color:var(--bdr-hi);}',
    '._pu_ctb{position:absolute;top:0;left:0;right:0;height:2px;opacity:.6;}',
    '._pu_cl{font-size:.7rem;letter-spacing:.07em;text-transform:uppercase;color:var(--mu);margin-bottom:5px;display:flex;align-items:center;gap:4px;}',
    '._pu_cv{font-size:2rem;font-weight:600;line-height:1;letter-spacing:-.035em;}',
    '._pu_cs{font-size:.75rem;color:var(--mu);margin-top:3px;}',
    '._pu_chr{font-size:.72rem;margin-top:3px;font-variant-numeric:tabular-nums;color:var(--mu2);}',
    '._pu_chr._drop{color:var(--red);}',
    '._pu_tap{position:absolute;bottom:8px;right:9px;font-size:.62rem;color:var(--mu2);}',

    // ── Pro bar ───────────────────────────────────────────────────────────────
    '._pu_pb2{margin-top:6px;}',
    '._pu_pb2r{display:flex;justify-content:space-between;margin-bottom:2px;}',
    '._pu_pb2p{font-size:.68rem;color:var(--mu);}',
    '._pu_pb2m{font-size:.68rem;color:var(--mu2);}',
    '._pu_pb2t{height:2px;background:var(--bdr);border-radius:99px;overflow:hidden;}',
    '._pu_pb2f{height:100%;border-radius:99px;transition:width .6s ease;}',

    // ── Expanded list ─────────────────────────────────────────────────────────
    '._pu_list{display:flex;flex-direction:column;gap:7px;}',
    '._pu_row{background:var(--surf);border:1px solid var(--bdr);border-radius:10px;padding:14px 15px;position:relative;overflow:hidden;opacity:0;animation:_pu_up .22s ease both;transition:border-color .15s,background .15s;cursor:pointer;display:flex;align-items:center;gap:11px;}',
    '._pu_row:hover{background:var(--surf2);border-color:var(--bdr-hi);}',
    '._pu_rib{position:absolute;top:0;left:0;bottom:0;width:2px;}',
    '._pu_rico{display:flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:8px;background:var(--bdr);flex-shrink:0;}',
    '._pu_rinfo{flex:1;min-width:0;}',
    '._pu_rlbl{font-size:.75rem;letter-spacing:.07em;text-transform:uppercase;color:var(--mu);margin-bottom:2px;}',
    '._pu_rval{font-size:1.85rem;font-weight:600;line-height:1;letter-spacing:-.03em;}',
    '._pu_rsub{font-size:.74rem;color:var(--mu);margin-top:2px;}',
    '._pu_rr{display:flex;flex-direction:column;align-items:flex-end;gap:4px;flex-shrink:0;}',
    '._pu_rhr{font-size:.76rem;font-variant-numeric:tabular-nums;color:var(--mu2);}',
    '._pu_rhr._drop{color:var(--red);}',
    '._pu_rtap{font-size:.62rem;color:var(--mu2);}',

    // ── Footer ────────────────────────────────────────────────────────────────
    '#_pu_pf{padding:7px 12px 9px;border-top:1px solid var(--sep);display:flex;align-items:center;justify-content:space-between;background:var(--hdr);}',
    '._pu_crow{display:flex;align-items:center;gap:5px;}',
    '._pu_ctext{font-size:.72rem;color:var(--mu);font-variant-numeric:tabular-nums;}',
    '._pu_ctrack{width:40px;height:1.5px;background:var(--bdr);border-radius:99px;overflow:hidden;}',
    '._pu_cfill{height:100%;background:var(--mu);border-radius:99px;transition:width 1s linear;}',
    '._pu_albl{font-size:.7rem;color:var(--mu2);}',

    // ── Graph view ────────────────────────────────────────────────────────────
    '#_pu_gv{display:none;animation:_pu_fadein .18s ease both;}',
    '._pu_gv_hdr{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;}',
    '._pu_back{display:flex;align-items:center;gap:4px;font-size:.82rem;color:var(--mu);cursor:pointer;padding:3px 0;border:none;background:transparent;transition:color .15s;font-family:inherit;}',
    '._pu_back:hover{color:var(--sub);}',
    '._pu_gv_name{font-size:.76rem;letter-spacing:.08em;text-transform:uppercase;color:var(--mu);}',
    '._pu_gv_val{font-size:2.4rem;font-weight:600;letter-spacing:-.04em;line-height:1;margin-bottom:2px;}',
    '._pu_gv_sub{font-size:.78rem;color:var(--mu);margin-bottom:10px;}',
    '._pu_gv_hr{font-size:.78rem;color:var(--mu2);font-variant-numeric:tabular-nums;margin-top:6px;}',
    '._pu_gv_hr._drop{color:var(--red);}',
    '._pu_graph_empty{display:flex;align-items:center;justify-content:center;height:90px;font-size:.76rem;color:var(--mu2);border:1px dashed var(--bdr);border-radius:8px;}',

    // ── Window pills (6h/12h/24h) ──────────────────────────────────────────────
    '._pu_wpills{display:flex;gap:3px;margin-bottom:10px;}',
    '._pu_wpill{font-size:.72rem;padding:4px 11px;border-radius:6px;border:1px solid var(--bdr);background:transparent;color:var(--mu);cursor:pointer;transition:all .15s;font-family:inherit;}',
    '._pu_wpill:hover{border-color:var(--bdr-hi);color:var(--sub);}',
    '._pu_wpill._wa{background:var(--grn);border-color:var(--grn);color:#fff;}',
  ].join('');
  document.head.appendChild(style);

  // ─── FAB ─────────────────────────────────────────────────────────────────────
  var fab = document.createElement('button');
  fab.id = '_pu_fab'; fab.title = 'Usage (Alt+U)';
  fab.innerHTML = '<svg width="15" height="15" viewBox="0 0 18 18" fill="currentColor"><rect x="1" y="9" width="4" height="8" rx="1.2"/><rect x="7" y="5" width="4" height="12" rx="1.2"/><rect x="13" y="1" width="4" height="16" rx="1.2"/></svg>';
  document.body.appendChild(fab);

  // ─── STATE ───────────────────────────────────────────────────────────────────
  var panel       = null;
  var open        = false;
  var expanded    = false;
  var theme       = 'system'; // 'system'|'light'|'dark'
  var graphWindow = 24;       // hours
  var countTimer  = null;
  var countVal    = 60;
  var graphMetric = null;
  var wasExpanded = false; // state before entering graph view
  var lastRl      = null;
  var lastSt      = null;
  var hrCache     = {};

  var prevValues = { pro: null, research: null, labs: null, upload: null };
  RefillPredictor.getLastValues(function (sv) { prevValues = sv; });
  chrome.storage.local.get(['pu_theme', 'pu_win'], function (d) {
    if (d.pu_theme) { theme = d.pu_theme; applyTheme(); }
    if (d.pu_win)   graphWindow = d.pu_win;
  });

  // ─── THEME ───────────────────────────────────────────────────────────────────
  function applyTheme() {
    [fab, panel].forEach(function (el) {
      if (!el) return;
      el.classList.remove('_fl', '_fd');
      if (theme === 'light') el.classList.add('_fl');
      if (theme === 'dark')  el.classList.add('_fd');
    });
  }

  function cycleTheme() {
    theme = theme === 'system' ? 'dark' : theme === 'dark' ? 'light' : 'system';
    chrome.storage.local.set({ pu_theme: theme });
    applyTheme();
    var btn = document.getElementById('_pu_thbtn');
    if (btn) btn.innerHTML = themeIconSVG();
    var lbl = document.getElementById('_pu_thlbl');
    if (lbl) lbl.textContent = theme === 'system' ? 'Auto' : theme === 'dark' ? 'Dark' : 'Light';
  }

  function themeIconSVG() {
    if (theme === 'light') return '<svg width="11" height="11" viewBox="0 0 14 14" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"><circle cx="7" cy="7" r="2.8"/><line x1="7" y1="0.5" x2="7" y2="2.5"/><line x1="7" y1="11.5" x2="7" y2="13.5"/><line x1="0.5" y1="7" x2="2.5" y2="7"/><line x1="11.5" y1="7" x2="13.5" y2="7"/><line x1="2.6" y1="2.6" x2="4" y2="4"/><line x1="10" y1="10" x2="11.4" y2="11.4"/><line x1="11.4" y1="2.6" x2="10" y2="4"/><line x1="4" y1="10" x2="2.6" y2="11.4"/></svg>';
    if (theme === 'dark')  return '<svg width="11" height="11" viewBox="0 0 14 14" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"><path d="M12 9a6 6 0 1 1-7-7 4 4 0 0 0 7 7z"/></svg>';
    return '<svg width="11" height="11" viewBox="0 0 14 14" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"><circle cx="7" cy="7" r="2.8"/><line x1="7" y1="0.5" x2="7" y2="2.5"/><line x1="7" y1="11.5" x2="7" y2="13.5"/><line x1="0.5" y1="7" x2="2.5" y2="7"/><line x1="11.5" y1="7" x2="13.5" y2="7"/></svg>';
  }

  // ─── ACCENT HELPERS ───────────────────────────────────────────────────────────
  function accentVar(val) {
    if (val == null) return 'var(--mu2)';
    if (val <= 3)   return 'var(--red)';
    if (val <= 10)  return 'var(--amber)';
    return 'var(--grn)';
  }

  function accentHex(val) {
    var light = (theme === 'light') || (theme === 'system' && window.matchMedia('(prefers-color-scheme:light)').matches);
    if (val == null) return light ? 'rgba(0,0,0,.18)' : 'rgba(255,255,255,.12)';
    if (val <= 3)   return light ? '#dc2626' : '#f87171';
    if (val <= 10)  return light ? '#d97706' : '#fbbf24';
    return light ? '#0ea66e' : '#34d399';
  }

  function updateFabStatus(values) {
    fab.classList.remove('_pu_warn', '_pu_low');
    if (!values) return;
    var v = [values.pro, values.research, values.labs, values.upload];
    if (v.some(function (x) { return x != null && x <= 3; }))  fab.classList.add('_pu_low');
    else if (v.some(function (x) { return x != null && x <= 10; })) fab.classList.add('_pu_warn');
  }

  // ─── ICONS ───────────────────────────────────────────────────────────────────
  function makeIcon(key, sz) {
    sz = sz || 9;
    var paths = {
      pro:      '<path d="M6 1l1.4 3h3.2l-2.6 1.9.9 3L6 7.1 3.1 8.9l.9-3L1.4 4h3.2z"/>',
      research: '<circle cx="5" cy="5" r="3.5" stroke="currentColor" stroke-width="1.5" fill="none"/><line x1="7.5" y1="7.5" x2="11" y2="11" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>',
      labs:     '<path d="M4.5 1v5L1.5 10.5h9L7.5 6V1" stroke="currentColor" stroke-width="1.5" fill="none" stroke-linecap="round" stroke-linejoin="round"/><line x1="3.5" y1="1" x2="8.5" y2="1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>',
      upload:   '<path d="M2 9.5h8M6 1.5v6M3.5 4L6 1.5 8.5 4" stroke="currentColor" stroke-width="1.5" fill="none" stroke-linecap="round" stroke-linejoin="round"/>'
    };
    return '<svg width="' + sz + '" height="' + sz + '" viewBox="0 0 12 12" fill="currentColor">' + (paths[key] || '') + '</svg>';
  }

  var metaMap = {
    pro:      { label: 'Pro',          max: PRO_MAX },
    research: { label: 'Pro Research', max: null    },
    labs:     { label: 'Labs',         max: null    },
    upload:   { label: 'Upload Limit', max: null    }
  };

  // ─── HOURLY STAT ─────────────────────────────────────────────────────────────
  // Finds the snapshot closest to 1hr ago (must be at least 30min old).
  // Positive net = consumed. Never shows gains (refills skew the number).
  function loadHourlyStats(currentValues, callback) {
    var keys = ['pro', 'research', 'labs', 'upload'];
    var out  = {}, pending = keys.length;
    keys.forEach(function (key) {
      RefillPredictor.getSnapshots(key, function (snaps) {
        var now = Date.now(), cur = currentValues[key];
        var result = null;
        if (cur != null && snaps.length) {
          // Find snapshot nearest to 1hr ago
          var target = now - ONE_HOUR_MS, best = null, bestD = Infinity;
          for (var i = 0; i < snaps.length; i++) {
            var d = Math.abs(snaps[i].ts - target);
            if (d < bestD) { bestD = d; best = snaps[i]; }
          }
          // Fallback: if nothing close to 1hr ago, use oldest snap that's ≥30min old
          if (!best || (now - best.ts) < 30 * 60 * 1000) {
            best = null;
            for (var j = 0; j < snaps.length; j++) {
              if ((now - snaps[j].ts) >= 30 * 60 * 1000) { best = snaps[j]; break; }
            }
          }
          if (best) {
            var net = best.val - cur; // positive = credits consumed
            if (net > 0) result = { net: net, approx: (now - best.ts) < ONE_HOUR_MS * 0.85 };
          }
        }
        out[key] = result;
        if (!--pending) callback(out);
      });
    });
  }

  function hrText(stat) {
    if (!stat) return null;
    var prefix = stat.approx ? '\u2248\u2212' : '\u2212';
    return prefix + stat.net + ' last hr';
  }

  // ─── GRAPH SVG ───────────────────────────────────────────────────────────────
  function renderGraphSVG(snapshots, color, W, yMax, winH) {
    var winMs = winH * ONE_HOUR_MS;
    W = W || 280;
    // Layout: PL = left pad for y-axis labels, PB = bottom pad for x-axis
    var PL = 38, PT = 8, PB = 30, IW = W - PL;
    var H = 120, IH = H - PT - PB;
    var now = Date.now(), winStart = now - winMs;

    var snaps = (snapshots || []).filter(function (s) { return s.ts >= winStart; });
    if (snaps.length < 2) return '<div class="_pu_graph_empty">Not enough data yet\u2026</div>';

    var yTop = yMax || Math.max.apply(null, snaps.map(function (s) { return s.val; }));
    if (!yTop) yTop = 1;

    function xOf(ts)  { return PL + ((ts - winStart) / winMs) * IW; }
    function yOf(val) { return PT + (1 - val / yTop) * IH; }

    // Segments
    var segs = [], cur = [];
    for (var i = 0; i < snaps.length; i++) {
      if (i > 0 && (snaps[i].ts - snaps[i-1].ts) > MAX_SEG_GAP) {
        if (cur.length) { segs.push(cur); cur = []; }
      }
      cur.push({ x: xOf(snaps[i].ts), y: yOf(snaps[i].val) });
    }
    if (cur.length) segs.push(cur);

    function segPath(seg) {
      return seg.map(function (p, i) {
        if (i === 0) return 'M' + p.x.toFixed(1) + ',' + p.y.toFixed(1);
        var pv = seg[i-1], cx = (pv.x + p.x) / 2;
        return 'C' + cx.toFixed(1) + ',' + pv.y.toFixed(1) + ' ' + cx.toFixed(1) + ',' + p.y.toFixed(1) + ' ' + p.x.toFixed(1) + ',' + p.y.toFixed(1);
      }).join(' ');
    }

    var solidD = segs.map(segPath).join(' ');
    var areaD  = segs.map(function (seg) {
      var base = (PT + IH).toFixed(1);
      return segPath(seg) + ' L' + seg[seg.length-1].x.toFixed(1) + ',' + base + ' L' + seg[0].x.toFixed(1) + ',' + base + ' Z';
    }).join(' ');

    var dashD = '';
    for (var s = 0; s < segs.length - 1; s++) {
      var a = segs[s][segs[s].length - 1], b = segs[s+1][0];
      var cx = ((a.x + b.x) / 2).toFixed(1);
      dashD += 'M' + a.x.toFixed(1) + ',' + a.y.toFixed(1) + ' C' + cx + ',' + a.y.toFixed(1) + ' ' + cx + ',' + b.y.toFixed(1) + ' ' + b.x.toFixed(1) + ',' + b.y.toFixed(1) + ' ';
    }

    var lp = segs[segs.length-1][segs[segs.length-1].length-1];
    var gid = '_gg' + Math.random().toString(36).slice(2, 6);

    // ── Y-axis: 4 labelled gridlines ────────────────────────────────────────
    var yGridHtml = '';
    var ySteps = [0.25, 0.5, 0.75, 1.0];
    for (var yi = 0; yi < ySteps.length; yi++) {
      var frac = ySteps[yi];
      var gy   = (PT + (1 - frac) * IH).toFixed(1);
      var lval = Math.round(yTop * frac);
      // gridline
      yGridHtml += '<line x1="' + PL + '" y1="' + gy + '" x2="' + W + '" y2="' + gy
        + '" stroke="currentColor" stroke-opacity="' + (frac === 1.0 ? '0.28' : '0.18') + '" stroke-width="' + (frac === 1.0 ? '1.2' : '0.8') + '" stroke-dasharray="' + (frac === 1.0 ? 'none' : '4,3') + '"/>';
      // label
      yGridHtml += '<text x="' + (PL - 5) + '" y="' + (parseFloat(gy) + 4) + '" text-anchor="end" font-size="10.5" font-weight="500" fill="currentColor" opacity="0.72">' + lval + '</text>';
    }
    // Y-axis baseline (left edge)
    yGridHtml += '<line x1="' + PL + '" y1="' + PT + '" x2="' + PL + '" y2="' + (PT + IH) + '" stroke="currentColor" stroke-opacity="0.22" stroke-width="1"/>';

    // ── X-axis: baseline + ticks + labels ───────────────────────────────────
    var baseY  = (PT + IH).toFixed(1);
    var xAxisHtml = '<line x1="' + PL + '" y1="' + baseY + '" x2="' + W + '" y2="' + baseY + '" stroke="currentColor" stroke-opacity="0.3" stroke-width="1.2"/>';
    var tickCount = 4;
    for (var t = 0; t <= tickCount; t++) {
      var hoursAgo = winH * (1 - t / tickCount);
      var tx = (PL + t / tickCount * IW).toFixed(1);
      var lbl = t === tickCount ? 'now' : hoursAgo < 1 ? '\u2212' + Math.round(hoursAgo * 60) + 'm' : '\u2212' + hoursAgo + 'h';
      var anc = t === 0 ? 'start' : t === tickCount ? 'end' : 'middle';
      // tick mark
      xAxisHtml += '<line x1="' + tx + '" y1="' + baseY + '" x2="' + tx + '" y2="' + (parseFloat(baseY) + 6) + '" stroke="currentColor" stroke-opacity="0.45" stroke-width="1.2"/>';
      // label
      xAxisHtml += '<text x="' + tx + '" y="' + (H - 3) + '" text-anchor="' + anc + '" font-size="12" font-weight="600" fill="currentColor" opacity="0.75">' + lbl + '</text>';
    }

    // ── Crosshair group (hidden until hover) ────────────────────────────────
    var chHtml = '<g id="' + gid + '_ch" visibility="hidden" pointer-events="none">'
      + '<line id="' + gid + '_vl" x1="0" y1="' + PT + '" x2="0" y2="' + (PT + IH) + '" stroke="currentColor" stroke-opacity="0.5" stroke-width="1.2" stroke-dasharray="3,2"/>'
      + '<circle id="' + gid + '_dot" cx="0" cy="0" r="4" fill="' + color + '" stroke="white" stroke-width="1.5"/>'
      + '<rect id="' + gid + '_tr" x="0" y="0" width="70" height="30" rx="5" fill="' + color + '" opacity="0.9"/>'
      + '<text id="' + gid + '_tv" x="0" y="0" font-size="12" font-weight="700" fill="white" text-anchor="middle"></text>'
      + '<text id="' + gid + '_ts2" x="0" y="0" font-size="9.5" fill="white" opacity="0.85" text-anchor="middle"></text>'
      + '</g>';
    // Invisible overlay rect to capture mouse events
    var overId = gid + '_ov';
    var overlayHtml = '<rect id="' + overId + '" x="' + PL + '" y="' + PT + '" width="' + IW + '" height="' + IH + '" fill="transparent" style="cursor:crosshair"/>';

    return '<svg id="' + gid + '" viewBox="0 0 ' + W + ' ' + H + '" width="' + W + '" height="' + H
      + '" xmlns="http://www.w3.org/2000/svg" style="display:block;overflow:visible;color:inherit"'
      + ' data-pl="' + PL + '" data-iw="' + IW + '" data-ih="' + IH + '" data-pt="' + PT + '"'
      + ' data-winstart="' + winStart + '" data-winms="' + winMs + '" data-ytop="' + yTop + '">'
      + '<defs><linearGradient id="' + gid + '_gr" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="' + color + '" stop-opacity="0.2"/><stop offset="100%" stop-color="' + color + '" stop-opacity="0.02"/></linearGradient></defs>'
      + yGridHtml
      + xAxisHtml
      + '<path d="' + areaD + '" fill="url(#' + gid + '_gr)"/>'
      + (dashD ? '<path d="' + dashD + '" fill="none" stroke="' + color + '" stroke-width="1" stroke-dasharray="3,4" stroke-linecap="round" opacity="0.35"/>' : '')
      + '<path d="' + solidD + '" fill="none" stroke="' + color + '" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" opacity="0.9"/>'
      + '<circle cx="' + lp.x.toFixed(1) + '" cy="' + lp.y.toFixed(1) + '" r="3.5" fill="' + color + '"/>'
      + '<circle cx="' + lp.x.toFixed(1) + '" cy="' + lp.y.toFixed(1) + '" r="6" fill="' + color + '" opacity="0.15"/>'
      + overlayHtml
      + chHtml
      + '</svg>';
  }

  // ─── CROSSHAIR ───────────────────────────────────────────────────────────────
  function attachCrosshair(wrap, snaps, color, W, yMax, winH) {
    var svg = wrap.querySelector('svg');
    if (!svg) return;
    var PL       = parseFloat(svg.getAttribute('data-pl'));
    var IW       = parseFloat(svg.getAttribute('data-iw'));
    var IH       = parseFloat(svg.getAttribute('data-ih'));
    var PT_val   = parseFloat(svg.getAttribute('data-pt'));
    var winStart = parseFloat(svg.getAttribute('data-winstart'));
    var winMs    = parseFloat(svg.getAttribute('data-winms'));
    var yTop     = parseFloat(svg.getAttribute('data-ytop'));

    var gid   = svg.id;
    var chGrp = svg.getElementById ? svg.getElementById(gid + '_ch') : svg.querySelector('#' + gid + '_ch');
    // querySelector with # and special chars needs escaping — use attribute selector
    chGrp  = svg.querySelector('[id="' + gid + '_ch"]');
    var vl   = svg.querySelector('[id="' + gid + '_vl"]');
    var dot  = svg.querySelector('[id="' + gid + '_dot"]');
    var tr   = svg.querySelector('[id="' + gid + '_tr"]');
    var tv   = svg.querySelector('[id="' + gid + '_tv"]');
    var ts2  = svg.querySelector('[id="' + gid + '_ts2"]');
    var ov   = svg.querySelector('[id="' + gid + '_ov"]');
    if (!ov || !chGrp) return;

    function fmt(d) {
      var h = d.getHours().toString().padStart(2,'0');
      var m = d.getMinutes().toString().padStart(2,'0');
      return h + ':' + m;
    }

    ov.addEventListener('mousemove', function (e) {
      var rect  = svg.getBoundingClientRect();
      var scale = rect.width / W;
      var mx    = (e.clientX - rect.left) / scale;
      var innerX = mx - PL;
      if (innerX < 0) innerX = 0;
      if (innerX > IW) innerX = IW;

      // Find nearest snap by x-position (which maps linearly to time)
      var tsCursor = winStart + (innerX / IW) * winMs;
      var best = null, bestD = Infinity;
      for (var i = 0; i < snaps.length; i++) {
        var d = Math.abs(snaps[i].ts - tsCursor);
        if (d < bestD) { bestD = d; best = snaps[i]; }
      }
      if (!best) return;

      var snapX = PL + ((best.ts - winStart) / winMs) * IW;
      var snapY = PT_val + (1 - best.val / yTop) * IH;

      // Vertical line
      vl.setAttribute('x1', snapX.toFixed(1));
      vl.setAttribute('x2', snapX.toFixed(1));
      // Dot
      dot.setAttribute('cx', snapX.toFixed(1));
      dot.setAttribute('cy', snapY.toFixed(1));

      // Tooltip box — 72px wide, 32px tall
      var TW = 80, TH = 36, TM = 8;
      var tx = snapX + TM;
      if (tx + TW > W - 2) tx = snapX - TW - TM;
      var ty = PT_val + 4;
      tr.setAttribute('x', tx.toFixed(1));
      tr.setAttribute('y', ty.toFixed(1));
      tr.setAttribute('width', TW);
      tr.setAttribute('height', TH);
      var mid = (tx + TW / 2).toFixed(1);
      tv.setAttribute('x', mid);
      tv.setAttribute('y', (ty + 14).toFixed(1));
      tv.textContent = best.val;
      ts2.setAttribute('x', mid);
      ts2.setAttribute('y', (ty + 27).toFixed(1));
      ts2.textContent = fmt(new Date(best.ts));

      chGrp.setAttribute('visibility', 'visible');
    });

    ov.addEventListener('mouseleave', function () {
      chGrp.setAttribute('visibility', 'hidden');
    });
  }

  // ─── GRAPH VIEW ───────────────────────────────────────────────────────────────
  function showGraphView(key) {
    graphMetric = key;
    var gv = document.getElementById('_pu_gv'), grid = document.getElementById('_pu_gridv');
    if (!gv || !grid) return;

    var meta = metaMap[key];
    var val = key === 'pro' ? (lastRl && lastRl.remaining_pro) :
              key === 'research' ? (lastRl && lastRl.remaining_research) :
              key === 'labs' ? (lastRl && lastRl.remaining_labs) :
              (lastSt && lastSt.upload_limit);
    var color = accentHex(val);

    var subLine = val != null ? val + ' remaining' : '\u2013';
    if (key === 'pro' && val != null) subLine += ' \u00b7 ' + Math.round((PRO_MAX - val) / PRO_MAX * 100) + '% used';

    var htxt = hrText(hrCache[key]);
    var hrHtml = htxt
      ? '<div class="_pu_gv_hr _drop">' + htxt + '</div>'
      : '<div class="_pu_gv_hr">\u2013 last hr</div>';

    // Force panel wide when showing graph (looks terrible at 380px)
    wasExpanded = expanded;
    if (!expanded) {
      expanded = true;
      var p = document.getElementById('_pu_panel');
      if (p) p.classList.add('_pu_wide');
    }
    var gw = 498; // 520px panel − 2×11px padding

    grid.style.display = 'none'; gv.style.display = 'block';
    gv.innerHTML =
      '<div class="_pu_gv_hdr">'
        + '<button class="_pu_back" id="_pu_bbk"><svg width="11" height="11" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><path d="M7 2L3 6l4 4"/></svg> Back</button>'
        + '<span class="_pu_gv_name">' + makeIcon(key, 10) + '&nbsp;' + meta.label + '</span>'
      + '</div>'
      + '<div class="_pu_wpills" id="_pu_wpills">'
        + [6, 12, 24].map(function (h) { return '<button class="_pu_wpill' + (h === graphWindow ? ' _wa' : '') + '" data-h="' + h + '">' + h + 'h</button>'; }).join('')
      + '</div>'
      + '<div class="_pu_gv_val" style="color:' + color + '">' + (val != null ? val : '\u2013') + '</div>'
      + '<div class="_pu_gv_sub">' + subLine + '</div>'
      + '<div id="_pu_gsvg"><div class="_pu_graph_empty">Loading\u2026</div></div>'
      + hrHtml;

    document.getElementById('_pu_bbk').addEventListener('click', hideGraphView);

    // Window pills
    var pills = gv.querySelectorAll('._pu_wpill');
    for (var i = 0; i < pills.length; i++) {
      pills[i].addEventListener('click', (function (pill) {
        return function () {
          graphWindow = parseInt(pill.getAttribute('data-h'), 10);
          chrome.storage.local.set({ pu_win: graphWindow });
          var pp = document.querySelectorAll('._pu_wpill');
          for (var k = 0; k < pp.length; k++) pp[k].classList.toggle('_wa', parseInt(pp[k].getAttribute('data-h'), 10) === graphWindow);
          refreshGraphSVG(key, color, gw, meta.max);
        };
      })(pills[i]));
    }

    refreshGraphSVG(key, color, gw, meta.max);
  }

  function refreshGraphSVG(key, color, gw, yMaxHint) {
    RefillPredictor.getSnapshots(key, function (snaps) {
      var wrap = document.getElementById('_pu_gsvg');
      if (!wrap) return;
      var yMax = yMaxHint || (snaps.length ? Math.max.apply(null, snaps.map(function (s) { return s.val; })) : null);
      wrap.innerHTML = renderGraphSVG(snaps, color, gw, yMax, graphWindow);
      attachCrosshair(wrap, snaps, color, gw, yMax, graphWindow);
    });
  }

  function hideGraphView() {
    graphMetric = null;
    // Restore pre-graph expand state
    if (!wasExpanded) {
      expanded = false;
      var p = document.getElementById('_pu_panel');
      if (p) p.classList.remove('_pu_wide');
    }
    var gv = document.getElementById('_pu_gv'), grid = document.getElementById('_pu_gridv');
    if (gv)   { gv.style.display = 'none'; gv.innerHTML = ''; }
    if (grid) { grid.style.display = ''; }
    // Re-render body with correct layout
    if (lastRl && lastSt) {
      var pb = document.getElementById('_pu_pb');
      if (pb) {
        pb.innerHTML = '<div id="_pu_gridv">' + renderCards(lastRl, lastSt) + '</div><div id="_pu_gv" style="display:none;"></div>';
        bindCardClicks(pb);
      }
    }
  }

  // ─── RENDER HELPERS ───────────────────────────────────────────────────────────
  function proBar(val, max, ac, cls) {
    var pct = Math.min(100, Math.round((max - val) / max * 100));
    return '<div class="' + cls + 'wrap"><div class="' + cls + 'r"><span class="' + cls + 'p">' + pct + '% used</span><span class="' + cls + 'm">/' + max + '</span></div>'
      + '<div class="' + cls + 't"><div class="' + cls + 'f" style="width:' + pct + '%;background:' + ac + '"></div></div></div>';
  }

  function renderCards(rl, st) {
    var fields = [
      { key:'pro',      val: rl.remaining_pro      },
      { key:'research', val: rl.remaining_research  },
      { key:'labs',     val: rl.remaining_labs      },
      { key:'upload',   val: st.upload_limit        }
    ];
    var html = '<div class="_pu_grid">';
    fields.forEach(function (f, i) {
      if (f.val == null) return;
      var meta = metaMap[f.key], av = accentVar(f.val), htxt = hrText(hrCache[f.key]);
      var hrHtml = htxt ? '<div class="_pu_chr _drop">' + htxt + '</div>' : '<div class="_pu_chr">\u2013</div>';
      var barHtml = (f.key === 'pro' && meta.max) ? proBar(f.val, meta.max, av, '_pu_pb2') : '';
      html += '<div class="_pu_card" data-m="' + f.key + '" style="animation-delay:' + (i*40) + 'ms">'
        + '<div class="_pu_ctb" style="background:' + av + '"></div>'
        + '<div class="_pu_cl">' + makeIcon(f.key, 9) + '&nbsp;' + meta.label + '</div>'
        + '<div class="_pu_cv" style="color:' + av + '">' + f.val + '</div>'
        + '<div class="_pu_cs">remaining</div>'
        + barHtml + hrHtml
        + '<div class="_pu_tap">tap for graph \u2192</div>'
        + '</div>';
    });
    return html + '</div>';
  }

  function renderRows(rl, st) {
    var fields = [
      { key:'pro',      val: rl.remaining_pro      },
      { key:'research', val: rl.remaining_research  },
      { key:'labs',     val: rl.remaining_labs      },
      { key:'upload',   val: st.upload_limit        }
    ];
    var html = '<div class="_pu_list">';
    fields.forEach(function (f, i) {
      if (f.val == null) return;
      var meta = metaMap[f.key], av = accentVar(f.val), htxt = hrText(hrCache[f.key]);
      var hrHtml = htxt ? '<div class="_pu_rhr _drop">' + htxt + '</div>' : '<div class="_pu_rhr">\u2013</div>';
      var barHtml = (f.key === 'pro' && meta.max) ? proBar(f.val, meta.max, av, '_pu_pb2') : '';
      html += '<div class="_pu_row" data-m="' + f.key + '" style="animation-delay:' + (i*35) + 'ms">'
        + '<div class="_pu_rib" style="background:' + av + '"></div>'
        + '<div class="_pu_rico" style="color:' + av + '">' + makeIcon(f.key, 14) + '</div>'
        + '<div class="_pu_rinfo">'
          + '<div class="_pu_rlbl">' + meta.label + '</div>'
          + '<div class="_pu_rval" style="color:' + av + '">' + f.val + '</div>'
          + '<div class="_pu_rsub">remaining</div>' + barHtml
        + '</div>'
        + '<div class="_pu_rr">' + hrHtml + '<div class="_pu_rtap">tap for graph</div></div>'
        + '</div>';
    });
    return html + '</div>';
  }

  function renderBody(rl, st) { return renderCards(rl, st); }

  function bindCardClicks(pb) {
    (pb || document).querySelectorAll('._pu_card').forEach(function (el) {
      el.addEventListener('click', function () { showGraphView(el.getAttribute('data-m')); });
    });
  }

  // ─── EXPAND ──────────────────────────────────────────────────────────────────
  function expandSVG(on) {
    return on
      ? '<svg width="12" height="12" viewBox="0 0 14 14" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><polyline points="4,2 2,2 2,4"/><polyline points="10,2 12,2 12,4"/><polyline points="4,12 2,12 2,10"/><polyline points="10,12 12,12 12,10"/></svg>'
      : '<svg width="12" height="12" viewBox="0 0 14 14" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><polyline points="1,5 1,1 5,1"/><polyline points="13,5 13,1 9,1"/><polyline points="1,9 1,13 5,13"/><polyline points="13,9 13,13 9,13"/></svg>';
  }

  function toggleExpand() {
    expanded = !expanded;
    var p = document.getElementById('_pu_panel'), eb = document.getElementById('_pu_xbtn');
    if (p)  p.classList.toggle('_pu_wide', expanded);
    if (eb) eb.innerHTML = expandSVG(expanded);
    // Layout (always 2x2 grid) doesn't change — no re-render needed
  }

  // ─── COUNTDOWN ───────────────────────────────────────────────────────────────
  function startCountdown() {
    if (countTimer) clearInterval(countTimer);
    countVal = 60; syncCount();
    countTimer = setInterval(function () {
      countVal--; syncCount();
      if (countVal <= 0) { clearInterval(countTimer); doFetch(); }
    }, 1000);
  }
  function syncCount() {
    var t = document.getElementById('_pu_ctext'), b = document.getElementById('_pu_cfill');
    if (t) t.textContent = countVal + 's';
    if (b) b.style.width = (countVal / 60 * 100) + '%';
  }

  // ─── FETCH ───────────────────────────────────────────────────────────────────
  function doFetch() {
    var dot = document.getElementById('_pu_dot'), ts = document.getElementById('_pu_ts'),
        pb  = document.getElementById('_pu_pb'),  pf = document.getElementById('_pu_pf'),
        rb  = document.getElementById('_pu_rbtn');
    if (!pb) return;
    if (rb) rb.disabled = true;
    if (dot) dot.className = '_pu_dot';
    if (pf) pf.style.display = 'none';
    if (!graphMetric) pb.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;padding:20px 0;gap:8px"><div class="_pu_sp"></div><div style="font-size:.6rem;color:var(--mu)">Fetching\u2026</div></div>';

    Promise.all([
      fetch('/rest/rate-limit/all', { credentials: 'include' }).then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); }),
      fetch('/rest/user/settings',  { credentials: 'include' }).then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
    ]).then(function (res) {
      lastRl = res[0]; lastSt = res[1];
      var nv = { pro: res[0].remaining_pro, research: res[0].remaining_research, labs: res[0].remaining_labs, upload: res[1].upload_limit };
      RefillPredictor.recordSnapshotBatch(nv);
      prevValues = nv;
      RefillPredictor.saveLastValues(nv);
      updateFabStatus(nv);

      loadHourlyStats(nv, function (stats) {
        hrCache = stats;
        if (!graphMetric) {
          pb.innerHTML = '<div id="_pu_gridv">' + renderBody(res[0], res[1]) + '</div><div id="_pu_gv" style="display:none;"></div>';
          bindCardClicks(pb);
        }
        if (dot) dot.className = '_pu_dot _live';
        if (ts)  ts.textContent = new Date().toLocaleTimeString();
        if (rb)  rb.disabled = false;
        if (pf)  pf.style.display = 'flex';
        startCountdown();
      });
    }).catch(function (err) {
      if (!graphMetric) pb.innerHTML = '<div style="text-align:center;padding:16px 0"><div style="font-size:.7rem;color:var(--red);font-weight:600">Failed to load</div><div style="font-size:.56rem;color:var(--mu);margin-top:3px">' + err.message + '</div></div>';
      if (dot) dot.className = '_pu_dot _err';
      if (rb)  rb.disabled = false;
    });
  }

  // ─── BUILD PANEL ─────────────────────────────────────────────────────────────
  function buildPanel() {
    var p = document.createElement('div');
    p.id = '_pu_panel';
    if (expanded) p.classList.add('_pu_wide');
    applyTheme(); // sets _fl/_fd on panel if needed (called after p is assigned above — fixed below)

    var thLbl = theme === 'system' ? 'Auto' : theme === 'dark' ? 'Dark' : 'Light';
    p.innerHTML =
      '<div id="_pu_ph">'
        + '<div class="_pu_hrow">'
          + '<div class="_pu_dot" id="_pu_dot"></div>'
          + '<div class="_pu_title">Perplexity <em>Usage</em></div>'
        + '</div>'
        + '<div class="_pu_hrow">'
          + '<span class="_pu_ts" id="_pu_ts"></span>'
          // Theme button
          + '<button class="_pu_rbtn" id="_pu_thbtn" title="Theme: ' + thLbl + '">' + themeIconSVG() + '</button>'
          // Expand button
          + '<button class="_pu_rbtn" id="_pu_xbtn" title="Expand">' + expandSVG(expanded) + '</button>'
          // Refresh button
          + '<button class="_pu_rbtn" id="_pu_rbtn" title="Refresh"><svg width="12" height="12" viewBox="0 0 14 14" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12.5 7A5.5 5.5 0 1 1 9.2 2.1"/><polyline points="9.5 1.5 9.2 4 11.7 4.3"/></svg></button>'
        + '</div>'
      + '</div>'
      + '<div id="_pu_pb">'
        + '<div style="display:flex;align-items:center;justify-content:center;padding:20px 0;gap:8px"><div class="_pu_sp"></div><div style="font-size:.6rem;color:var(--mu)">Fetching\u2026</div></div>'
      + '</div>'
      + '<div id="_pu_pf" style="display:none;">'
        + '<div class="_pu_crow"><span class="_pu_ctext" id="_pu_ctext">60s</span><div class="_pu_ctrack"><div class="_pu_cfill" id="_pu_cfill" style="width:100%"></div></div></div>'
        + '<span class="_pu_albl">auto-refresh</span>'
      + '</div>';
    return p;
  }

  function openPanel() {
    if (panel) panel.remove();
    panel = buildPanel();
    // Apply theme class directly on the newly created panel element
    panel.classList.remove('_fl', '_fd');
    if (theme === 'light') panel.classList.add('_fl');
    if (theme === 'dark')  panel.classList.add('_fd');
    document.body.appendChild(panel);

    document.getElementById('_pu_rbtn').addEventListener('click', function () { if (countTimer) clearInterval(countTimer); hideGraphView(); doFetch(); });
    document.getElementById('_pu_xbtn').addEventListener('click', function (e) { e.stopPropagation(); toggleExpand(); });
    document.getElementById('_pu_thbtn').addEventListener('click', function (e) { e.stopPropagation(); cycleTheme(); });
    doFetch();
  }

  function closePanel() {
    if (countTimer) clearInterval(countTimer);
    graphMetric = null;
    if (panel) { panel.remove(); panel = null; }
  }

  function togglePanel() {
    open = !open;
    fab.classList.toggle('_pu_on', open);
    if (open) openPanel(); else closePanel();
  }

  // ─── EVENTS ──────────────────────────────────────────────────────────────────
  fab.addEventListener('click', function (e) { e.stopPropagation(); togglePanel(); });
  document.addEventListener('click', function (e) {
    if (open && panel && !panel.contains(e.target) && e.target !== fab) {
      open = false; fab.classList.remove('_pu_on'); closePanel();
    }
  }, true);
  document.addEventListener('keydown', function (e) {
    if (e.altKey && e.key === 'u') { e.preventDefault(); togglePanel(); }
    if (e.key === 'Escape') { if (graphMetric) hideGraphView(); else if (open) { open = false; fab.classList.remove('_pu_on'); closePanel(); } }
  });

  // ─── MESSAGE LISTENER ────────────────────────────────────────────────────────
  chrome.runtime.onMessage.addListener(function (req, sender, sendResponse) {
    if (req.type !== 'FETCH_USAGE') return;
    Promise.all([
      fetch('/rest/rate-limit/all', { credentials: 'include' }).then(function (r) { return r.json(); }),
      fetch('/rest/user/settings',  { credentials: 'include' }).then(function (r) { return r.json(); })
    ]).then(function (res) { sendResponse({ ok: true, rateLimit: res[0], settings: res[1] }); })
     .catch(function (err) { sendResponse({ ok: false, error: err.message }); });
    return true;
  });

  RefillPredictor.getLastValues(function (sv) { updateFabStatus(sv); });

})();
