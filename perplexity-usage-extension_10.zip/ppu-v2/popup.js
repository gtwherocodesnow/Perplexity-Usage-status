// popup.js
var PRO_MAX     = 200;
var ONE_HOUR_MS = 60 * 60 * 1000;
var MAX_SEG_GAP = 6 * 60 * 1000;

var countdownVal   = 60;
var countdownTimer = null;
var lastRl         = null;
var lastSt         = null;
var hrCache        = {};
var expanded       = false;
var theme          = 'system'; // 'system'|'light'|'dark'
var graphWindow    = 24;
var graphKey       = null;
var wasExpanded    = false;

var dotEl      = document.getElementById('dot');
var tsEl       = document.getElementById('ts');
var bodyEl     = document.getElementById('body');
var footerEl   = document.getElementById('footer');
var refreshBtn = document.getElementById('refresh-btn');
var expandBtn  = document.getElementById('expand-btn');
var themeBtn   = document.getElementById('theme-btn');
var countText  = document.getElementById('countdown-text');
var countBar   = document.getElementById('countdown-bar');
var openBtn    = document.getElementById('open-perplexity');

// Load persisted prefs first
chrome.storage.local.get(['pu_theme', 'pu_win'], function (d) {
  if (d.pu_theme) { theme = d.pu_theme; applyTheme(); }
  if (d.pu_win)   graphWindow = d.pu_win;
});

refreshBtn.addEventListener('click', function () { graphKey = null; fetchData(); });
openBtn.addEventListener('click', function () { chrome.tabs.create({ url: 'https://www.perplexity.ai' }); });
expandBtn.addEventListener('click', toggleExpand);
themeBtn.addEventListener('click', cycleTheme);

// ─── THEME ───────────────────────────────────────────────────────────────────
function applyTheme() {
  document.documentElement.classList.remove('theme-light', 'theme-dark');
  if (theme === 'light') document.documentElement.classList.add('theme-light');
  if (theme === 'dark')  document.documentElement.classList.add('theme-dark');
  themeBtn.innerHTML = themeIconSVG();
  themeBtn.title = 'Theme: ' + (theme === 'system' ? 'Auto' : theme === 'dark' ? 'Dark' : 'Light');
}

function cycleTheme() {
  theme = theme === 'system' ? 'dark' : theme === 'dark' ? 'light' : 'system';
  chrome.storage.local.set({ pu_theme: theme });
  applyTheme();
}

function themeIconSVG() {
  if (theme === 'light') return '<svg width="12" height="12" viewBox="0 0 14 14" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"><circle cx="7" cy="7" r="2.8"/><line x1="7" y1="0.5" x2="7" y2="2.5"/><line x1="7" y1="11.5" x2="7" y2="13.5"/><line x1="0.5" y1="7" x2="2.5" y2="7"/><line x1="11.5" y1="7" x2="13.5" y2="7"/><line x1="2.6" y1="2.6" x2="4" y2="4"/><line x1="10" y1="10" x2="11.4" y2="11.4"/><line x1="11.4" y1="2.6" x2="10" y2="4"/><line x1="4" y1="10" x2="2.6" y2="11.4"/></svg>';
  if (theme === 'dark')  return '<svg width="12" height="12" viewBox="0 0 14 14" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"><path d="M12 9a6 6 0 1 1-7-7 4 4 0 0 0 7 7z"/></svg>';
  return '<svg width="12" height="12" viewBox="0 0 14 14" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"><circle cx="7" cy="7" r="2.8"/><line x1="7" y1="0.5" x2="7" y2="2.5"/><line x1="7" y1="11.5" x2="7" y2="13.5"/><line x1="0.5" y1="7" x2="2.5" y2="7"/><line x1="11.5" y1="7" x2="13.5" y2="7"/></svg>';
}

// ─── EXPAND ──────────────────────────────────────────────────────────────────
function toggleExpand() {
  expanded = !expanded;
  document.body.classList.toggle('expanded', expanded);
  expandBtn.innerHTML = expandSVG(expanded);
  // Layout (always 2x2 grid) doesn't change — no re-render needed
}

function expandSVG(on) {
  return on
    ? '<svg width="12" height="12" viewBox="0 0 14 14" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><polyline points="4,2 2,2 2,4"/><polyline points="10,2 12,2 12,4"/><polyline points="4,12 2,12 2,10"/><polyline points="10,12 12,12 12,10"/></svg>'
    : '<svg width="12" height="12" viewBox="0 0 14 14" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><polyline points="1,5 1,1 5,1"/><polyline points="13,5 13,1 9,1"/><polyline points="1,9 1,13 5,13"/><polyline points="13,9 13,13 9,13"/></svg>';
}

// ─── ACCENT ──────────────────────────────────────────────────────────────────
var metaMap = {
  pro:      { label: 'Pro',          max: PRO_MAX },
  research: { label: 'Pro Research', max: null    },
  labs:     { label: 'Labs',         max: null    },
  upload:   { label: 'Upload Limit', max: null    }
};

function colFor(val) {
  if (val == null) return 'var(--mu2)';
  if (val <= 3)   return 'var(--red)';
  if (val <= 10)  return 'var(--amber)';
  return 'var(--grn)';
}

function colHex(val) {
  var light = theme === 'light' || (theme === 'system' && window.matchMedia('(prefers-color-scheme:light)').matches);
  if (val == null) return light ? 'rgba(0,0,0,.18)' : 'rgba(255,255,255,.12)';
  if (val <= 3)   return light ? '#dc2626' : '#f87171';
  if (val <= 10)  return light ? '#d97706' : '#fbbf24';
  return light ? '#0ea66e' : '#34d399';
}

function makeIcon(key, sz) {
  sz = sz || 9;
  var d = {
    pro:      '<path d="M6 1l1.4 3h3.2l-2.6 1.9.9 3L6 7.1 3.1 8.9l.9-3L1.4 4h3.2z"/>',
    research: '<circle cx="5" cy="5" r="3.5" stroke="currentColor" stroke-width="1.5" fill="none"/><line x1="7.5" y1="7.5" x2="11" y2="11" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>',
    labs:     '<path d="M4.5 1v5L1.5 10.5h9L7.5 6V1" stroke="currentColor" stroke-width="1.5" fill="none" stroke-linecap="round" stroke-linejoin="round"/><line x1="3.5" y1="1" x2="8.5" y2="1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>',
    upload:   '<path d="M2 9.5h8M6 1.5v6M3.5 4L6 1.5 8.5 4" stroke="currentColor" stroke-width="1.5" fill="none" stroke-linecap="round" stroke-linejoin="round"/>'
  };
  return '<svg width="' + sz + '" height="' + sz + '" viewBox="0 0 12 12" fill="currentColor">' + (d[key]||'') + '</svg>';
}

// ─── HOURLY STAT ─────────────────────────────────────────────────────────────
function loadHourlyStats(currentValues, callback) {
  var keys = ['pro', 'research', 'labs', 'upload'], out = {}, pending = keys.length;
  keys.forEach(function (key) {
    RefillPredictor.getSnapshots(key, function (snaps) {
      var now = Date.now(), cur = currentValues[key], result = null;
      if (cur != null && snaps.length) {
        var target = now - ONE_HOUR_MS, best = null, bestD = Infinity;
        for (var i = 0; i < snaps.length; i++) {
          var d = Math.abs(snaps[i].ts - target);
          if (d < bestD) { bestD = d; best = snaps[i]; }
        }
        // Require at least 30min old; if best is newer, find oldest ≥30min
        if (!best || (now - best.ts) < 30 * 60 * 1000) {
          best = null;
          for (var j = 0; j < snaps.length; j++) {
            if ((now - snaps[j].ts) >= 30 * 60 * 1000) { best = snaps[j]; break; }
          }
        }
        if (best) {
          var net = best.val - cur;
          if (net > 0) result = { net: net, approx: (now - best.ts) < ONE_HOUR_MS * 0.85 };
        }
      }
      out[key] = result;
      if (!--pending) callback(out);
    });
  });
}

function hrText(stat) {
  if (!stat) return null;
  return (stat.approx ? '\u2248\u2212' : '\u2212') + stat.net + ' last hr';
}

// ─── GRAPH SVG ───────────────────────────────────────────────────────────────
function renderGraphSVG(snapshots, color, W, yMax, winH) {
  var winMs = winH * ONE_HOUR_MS;
  W = W || 280;
  var PL = 38, PT = 8, PB = 30, IW = W - PL;
  var H = 120, IH = H - PT - PB;
  var now = Date.now(), winStart = now - winMs;

  var snaps = (snapshots || []).filter(function (s) { return s.ts >= winStart; });
  if (snaps.length < 2) return '<div class="graph-empty">Not enough data yet\u2026</div>';

  var yTop = yMax || Math.max.apply(null, snaps.map(function (s) { return s.val; }));
  if (!yTop) yTop = 1;

  function xOf(ts)  { return PL + ((ts - winStart) / winMs) * IW; }
  function yOf(val) { return PT + (1 - val / yTop) * IH; }

  var segs = [], cur = [];
  for (var i = 0; i < snaps.length; i++) {
    if (i > 0 && (snaps[i].ts - snaps[i-1].ts) > MAX_SEG_GAP) {
      if (cur.length) { segs.push(cur); cur = []; }
    }
    cur.push({ x: xOf(snaps[i].ts), y: yOf(snaps[i].val) });
  }
  if (cur.length) segs.push(cur);

  function segPath(seg) {
    return seg.map(function (p, i) {
      if (i === 0) return 'M' + p.x.toFixed(1) + ',' + p.y.toFixed(1);
      var pv = seg[i-1], cx = ((pv.x + p.x) / 2).toFixed(1);
      return 'C' + cx + ',' + pv.y.toFixed(1) + ' ' + cx + ',' + p.y.toFixed(1) + ' ' + p.x.toFixed(1) + ',' + p.y.toFixed(1);
    }).join(' ');
  }

  var solidD = segs.map(segPath).join(' ');
  var base   = (PT + IH).toFixed(1);
  var areaD  = segs.map(function (s) {
    return segPath(s) + ' L' + s[s.length-1].x.toFixed(1) + ',' + base + ' L' + s[0].x.toFixed(1) + ',' + base + ' Z';
  }).join(' ');

  var dashD = '';
  for (var ds = 0; ds < segs.length - 1; ds++) {
    var da = segs[ds][segs[ds].length-1], db = segs[ds+1][0];
    var dcx = ((da.x + db.x) / 2).toFixed(1);
    dashD += 'M' + da.x.toFixed(1) + ',' + da.y.toFixed(1) + ' C' + dcx + ',' + da.y.toFixed(1) + ' ' + dcx + ',' + db.y.toFixed(1) + ' ' + db.x.toFixed(1) + ',' + db.y.toFixed(1) + ' ';
  }

  var lp = segs[segs.length-1][segs[segs.length-1].length-1];
  var gid = 'pg' + Math.random().toString(36).slice(2, 6);

  // Y-axis gridlines + labels
  var yGridHtml = '';
  var ySteps = [0.25, 0.5, 0.75, 1.0];
  for (var yi = 0; yi < ySteps.length; yi++) {
    var frac = ySteps[yi];
    var gy   = (PT + (1 - frac) * IH).toFixed(1);
    var lval = Math.round(yTop * frac);
    yGridHtml += '<line x1="' + PL + '" y1="' + gy + '" x2="' + W + '" y2="' + gy
      + '" stroke="currentColor" stroke-opacity="' + (frac === 1.0 ? '0.28' : '0.18') + '" stroke-width="' + (frac === 1.0 ? '1.2' : '0.8') + '" stroke-dasharray="' + (frac === 1.0 ? 'none' : '4,3') + '"/>';
    yGridHtml += '<text x="' + (PL - 5) + '" y="' + (parseFloat(gy) + 4) + '" text-anchor="end" font-size="10.5" font-weight="500" fill="currentColor" opacity="0.72">' + lval + '</text>';
  }
  yGridHtml += '<line x1="' + PL + '" y1="' + PT + '" x2="' + PL + '" y2="' + (PT + IH) + '" stroke="currentColor" stroke-opacity="0.22" stroke-width="1"/>';

  // X-axis baseline + ticks + labels
  var xAxisHtml = '<line x1="' + PL + '" y1="' + base + '" x2="' + W + '" y2="' + base + '" stroke="currentColor" stroke-opacity="0.3" stroke-width="1.2"/>';
  var tickCount = 4;
  for (var t = 0; t <= tickCount; t++) {
    var hoursAgo = winH * (1 - t / tickCount);
    var tx = (PL + t / tickCount * IW).toFixed(1);
    var lbl = t === tickCount ? 'now' : hoursAgo < 1 ? '\u2212' + Math.round(hoursAgo * 60) + 'm' : '\u2212' + hoursAgo + 'h';
    var anc = t === 0 ? 'start' : t === tickCount ? 'end' : 'middle';
    xAxisHtml += '<line x1="' + tx + '" y1="' + base + '" x2="' + tx + '" y2="' + (parseFloat(base) + 6) + '" stroke="currentColor" stroke-opacity="0.45" stroke-width="1.2"/>';
    xAxisHtml += '<text x="' + tx + '" y="' + (H - 3) + '" text-anchor="' + anc + '" font-size="12" font-weight="600" fill="currentColor" opacity="0.75">' + lbl + '</text>';
  }

  // Crosshair group
  var chHtml = '<g id="' + gid + '_ch" visibility="hidden" pointer-events="none">'
    + '<line id="' + gid + '_vl" x1="0" y1="' + PT + '" x2="0" y2="' + (PT + IH) + '" stroke="currentColor" stroke-opacity="0.5" stroke-width="1.2" stroke-dasharray="3,2"/>'
    + '<circle id="' + gid + '_dot" cx="0" cy="0" r="4" fill="' + color + '" stroke="white" stroke-width="1.5"/>'
    + '<rect id="' + gid + '_tr" x="0" y="0" width="80" height="36" rx="5" fill="' + color + '" opacity="0.9"/>'
    + '<text id="' + gid + '_tv" x="0" y="0" font-size="12" font-weight="700" fill="white" text-anchor="middle"></text>'
    + '<text id="' + gid + '_ts2" x="0" y="0" font-size="9.5" fill="white" opacity="0.85" text-anchor="middle"></text>'
    + '</g>';
  var overId = gid + '_ov';
  var overlayHtml = '<rect id="' + overId + '" x="' + PL + '" y="' + PT + '" width="' + IW + '" height="' + IH + '" fill="transparent" style="cursor:crosshair"/>';

  return '<svg id="' + gid + '" viewBox="0 0 ' + W + ' ' + H + '" width="' + W + '" height="' + H
    + '" xmlns="http://www.w3.org/2000/svg" style="display:block;overflow:visible;color:inherit"'
    + ' data-pl="' + PL + '" data-iw="' + IW + '" data-ih="' + IH + '" data-pt="' + PT + '"'
    + ' data-winstart="' + winStart + '" data-winms="' + winMs + '" data-ytop="' + yTop + '">'
    + '<defs><linearGradient id="' + gid + '_gr" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="' + color + '" stop-opacity="0.2"/><stop offset="100%" stop-color="' + color + '" stop-opacity="0.02"/></linearGradient></defs>'
    + yGridHtml
    + xAxisHtml
    + '<path d="' + areaD + '" fill="url(#' + gid + '_gr)"/>'
    + (dashD ? '<path d="' + dashD + '" fill="none" stroke="' + color + '" stroke-width="1" stroke-dasharray="3,4" stroke-linecap="round" opacity="0.35"/>' : '')
    + '<path d="' + solidD + '" fill="none" stroke="' + color + '" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" opacity="0.9"/>'
    + '<circle cx="' + lp.x.toFixed(1) + '" cy="' + lp.y.toFixed(1) + '" r="3.5" fill="' + color + '"/>'
    + '<circle cx="' + lp.x.toFixed(1) + '" cy="' + lp.y.toFixed(1) + '" r="6" fill="' + color + '" opacity="0.15"/>'
    + overlayHtml
    + chHtml
    + '</svg>';
}

function attachCrosshair(wrap, snaps, color, W, yMax, winH) {
  var svg = wrap.querySelector('svg');
  if (!svg) return;
  var PL       = parseFloat(svg.getAttribute('data-pl'));
  var IW       = parseFloat(svg.getAttribute('data-iw'));
  var IH       = parseFloat(svg.getAttribute('data-ih'));
  var PT_val   = parseFloat(svg.getAttribute('data-pt'));
  var winStart = parseFloat(svg.getAttribute('data-winstart'));
  var winMs    = parseFloat(svg.getAttribute('data-winms'));
  var yTop     = parseFloat(svg.getAttribute('data-ytop'));
  var gid      = svg.id;

  function q(id) { return svg.querySelector('[id="' + id + '"]'); }
  var chGrp = q(gid + '_ch'), vl = q(gid + '_vl'), dot = q(gid + '_dot');
  var tr = q(gid + '_tr'), tv = q(gid + '_tv'), ts2 = q(gid + '_ts2');
  var ov = q(gid + '_ov');
  if (!ov || !chGrp) return;

  function fmt(d) {
    return d.getHours().toString().padStart(2,'0') + ':' + d.getMinutes().toString().padStart(2,'0');
  }

  ov.addEventListener('mousemove', function (e) {
    var rect = svg.getBoundingClientRect();
    var scale = rect.width / W;
    var mx = (e.clientX - rect.left) / scale;
    var innerX = Math.max(0, Math.min(IW, mx - PL));
    var tsCursor = winStart + (innerX / IW) * winMs;
    var best = null, bestD = Infinity;
    for (var i = 0; i < snaps.length; i++) {
      var d = Math.abs(snaps[i].ts - tsCursor);
      if (d < bestD) { bestD = d; best = snaps[i]; }
    }
    if (!best) return;
    var sx = PL + ((best.ts - winStart) / winMs) * IW;
    var sy = PT_val + (1 - best.val / yTop) * IH;
    vl.setAttribute('x1', sx.toFixed(1)); vl.setAttribute('x2', sx.toFixed(1));
    dot.setAttribute('cx', sx.toFixed(1)); dot.setAttribute('cy', sy.toFixed(1));
    var TW = 80, TH = 36, TM = 8;
    var tx = sx + TM;
    if (tx + TW > W - 2) tx = sx - TW - TM;
    var ty = PT_val + 4;
    tr.setAttribute('x', tx.toFixed(1)); tr.setAttribute('y', ty.toFixed(1));
    tr.setAttribute('width', TW); tr.setAttribute('height', TH);
    var mid = (tx + TW / 2).toFixed(1);
    tv.setAttribute('x', mid); tv.setAttribute('y', (ty + 14).toFixed(1));
    tv.textContent = best.val;
    ts2.setAttribute('x', mid); ts2.setAttribute('y', (ty + 27).toFixed(1));
    ts2.textContent = fmt(new Date(best.ts));
    chGrp.setAttribute('visibility', 'visible');
  });
  ov.addEventListener('mouseleave', function () {
    chGrp.setAttribute('visibility', 'hidden');
  });
}


// ─── GRAPH VIEW ───────────────────────────────────────────────────────────────
function showGraphView(key) {
  graphKey = key;
  var meta = metaMap[key];
  var val = key === 'pro' ? lastRl.remaining_pro :
            key === 'research' ? lastRl.remaining_research :
            key === 'labs' ? lastRl.remaining_labs : lastSt.upload_limit;
  var color = colHex(val);
  var sub = val != null ? val + ' remaining' : '\u2013';
  if (key === 'pro' && val != null) sub += ' \u00b7 ' + Math.round((PRO_MAX - val) / PRO_MAX * 100) + '% used';
  var htxt = hrText(hrCache[key]);
  var hrHtml = htxt ? '<div class="graph-hr drop">' + htxt + '</div>' : '<div class="graph-hr muted">\u2013 last hr</div>';
  // Always expand popup to wide when showing graph
  wasExpanded = expanded;
  if (!expanded) {
    expanded = true;
    document.body.classList.add('expanded');
    expandBtn.innerHTML = expandSVG(true);
  }
  var gw = 538; // 560px body − 2×11px padding

  bodyEl.innerHTML =
    '<div class="graph-view">'
      + '<div class="graph-hdr">'
        + '<button class="graph-back" id="gbk"><svg width="11" height="11" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><path d="M7 2L3 6l4 4"/></svg> Back</button>'
        + '<span class="graph-name">' + makeIcon(key, 10) + '&nbsp;' + meta.label + '</span>'
      + '</div>'
      + '<div class="wpills">'
        + [6, 12, 24].map(function (h) { return '<button class="wpill' + (h === graphWindow ? ' wa' : '') + '" data-h="' + h + '">' + h + 'h</button>'; }).join('')
      + '</div>'
      + '<div class="graph-val" style="color:' + color + '">' + (val != null ? val : '\u2013') + '</div>'
      + '<div class="graph-sub">' + sub + '</div>'
      + '<div id="gsvg"><div class="graph-empty">Loading\u2026</div></div>'
      + hrHtml
    + '</div>';

  document.getElementById('gbk').addEventListener('click', function () {
    graphKey = null;
    // Restore pre-graph expand state
    if (!wasExpanded) {
      expanded = false;
      document.body.classList.remove('expanded');
      expandBtn.innerHTML = expandSVG(false);
    }
    bodyEl.innerHTML = renderCards(lastRl, lastSt);
    bindCardClicks();
  });

  bodyEl.querySelectorAll('.wpill').forEach(function (pill) {
    pill.addEventListener('click', function () {
      graphWindow = parseInt(pill.getAttribute('data-h'), 10);
      chrome.storage.local.set({ pu_win: graphWindow });
      bodyEl.querySelectorAll('.wpill').forEach(function (p) { p.classList.toggle('wa', parseInt(p.getAttribute('data-h'), 10) === graphWindow); });
      loadGraph(key, color, gw, meta.max);
    });
  });

  loadGraph(key, color, gw, meta.max);
}

function loadGraph(key, color, gw, yMaxHint) {
  RefillPredictor.getSnapshots(key, function (snaps) {
    var wrap = document.getElementById('gsvg');
    if (!wrap) return;
    var yMax = yMaxHint || (snaps.length ? Math.max.apply(null, snaps.map(function (s) { return s.val; })) : null);
    wrap.innerHTML = renderGraphSVG(snaps, color, gw, yMax, graphWindow);
    attachCrosshair(wrap, snaps, color, gw, yMax, graphWindow);
  });
}

// ─── CARDS / ROWS ────────────────────────────────────────────────────────────
function proBarHtml(val, max, col, prefix) {
  var pct = Math.min(100, Math.round((max - val) / max * 100));
  return '<div class="' + prefix + 'bar-wrap"><div class="' + prefix + 'bar-row"><span class="' + prefix + 'bar-pct">' + pct + '% used</span><span class="' + prefix + 'bar-max">/' + max + '</span></div>'
    + '<div class="' + prefix + 'bar-track"><div class="' + prefix + 'bar-fill" style="width:' + pct + '%;background:' + col + '"></div></div></div>';
}

function renderCards(rl, st) {
  var fields = [
    { key:'pro',      val: rl.remaining_pro      },
    { key:'research', val: rl.remaining_research  },
    { key:'labs',     val: rl.remaining_labs      },
    { key:'upload',   val: st.upload_limit        }
  ];
  var html = '<div class="cards">';
  fields.forEach(function (f, i) {
    if (f.val == null) return;
    var meta = metaMap[f.key], col = colFor(f.val), htxt = hrText(hrCache[f.key]);
    var hr = htxt ? '<div class="card-hr drop">' + htxt + '</div>' : '<div class="card-hr muted">\u2013</div>';
    var bar = (f.key === 'pro' && meta.max) ? proBarHtml(f.val, meta.max, col, 'c-') : '';
    html += '<div class="card" data-k="' + f.key + '" style="animation-delay:' + (i*40) + 'ms">'
      + '<div class="card-top" style="background:' + col + '"></div>'
      + '<div class="card-lbl">' + makeIcon(f.key, 9) + '&nbsp;' + meta.label + '</div>'
      + '<div class="card-val" style="color:' + col + '">' + f.val + '</div>'
      + '<div class="card-sub">remaining</div>'
      + bar + hr
      + '<div class="card-tap">tap for graph</div>'
      + '</div>';
  });
  return html + '</div>';
}

function renderRows(rl, st) {
  var fields = [
    { key:'pro',      val: rl.remaining_pro      },
    { key:'research', val: rl.remaining_research  },
    { key:'labs',     val: rl.remaining_labs      },
    { key:'upload',   val: st.upload_limit        }
  ];
  var html = '<div class="rows">';
  fields.forEach(function (f, i) {
    if (f.val == null) return;
    var meta = metaMap[f.key], col = colFor(f.val), htxt = hrText(hrCache[f.key]);
    var hr = htxt ? '<div class="row-hr drop">' + htxt + '</div>' : '<div class="row-hr muted">\u2013</div>';
    var bar = (f.key === 'pro' && meta.max) ? proBarHtml(f.val, meta.max, col, 'r-') : '';
    html += '<div class="row-card" data-k="' + f.key + '" style="animation-delay:' + (i*35) + 'ms">'
      + '<div class="row-bar" style="background:' + col + '"></div>'
      + '<div class="row-icon" style="color:' + col + '">' + makeIcon(f.key, 14) + '</div>'
      + '<div class="row-info">'
        + '<div class="row-lbl">' + meta.label + '</div>'
        + '<div class="row-val" style="color:' + col + '">' + f.val + '</div>'
        + '<div class="row-sub">remaining</div>' + bar
      + '</div>'
      + '<div class="row-right">' + hr + '<div class="row-tap">tap for graph</div></div>'
      + '</div>';
  });
  return html + '</div>';
}

function renderBody(rl, st) { return renderCards(rl, st); }

function bindCardClicks() {
  bodyEl.querySelectorAll('.card').forEach(function (el) {
    el.addEventListener('click', function () { showGraphView(el.getAttribute('data-k')); });
  });
}

// ─── COUNTDOWN ───────────────────────────────────────────────────────────────
function startCountdown() {
  if (countdownTimer) clearInterval(countdownTimer);
  countdownVal = 60; footerEl.style.display = 'flex';
  countdownTimer = setInterval(function () {
    countdownVal--;
    countText.textContent = countdownVal + 's';
    countBar.style.width = (countdownVal / 60 * 100) + '%';
    if (countdownVal <= 0) { clearInterval(countdownTimer); fetchData(); }
  }, 1000);
}

// ─── FETCH ───────────────────────────────────────────────────────────────────
function getPerplexityTab(cb) {
  chrome.tabs.query({ url: 'https://www.perplexity.ai/*' }, function (tabs) {
    if (tabs && tabs.length) { cb(null, tabs[0]); return; }
    chrome.tabs.create({ url: 'https://www.perplexity.ai', active: false }, function (tab) {
      function onUpd(tid, info) { if (tid === tab.id && info.status === 'complete') { chrome.tabs.onUpdated.removeListener(onUpd); setTimeout(function () { cb(null, tab); }, 800); } }
      chrome.tabs.onUpdated.addListener(onUpd);
    });
  });
}

function fetchData() {
  if (countdownTimer) clearInterval(countdownTimer);
  refreshBtn.disabled = true; dotEl.className = 'status-dot'; footerEl.style.display = 'none';
  if (!graphKey) bodyEl.innerHTML = '<div class="loading"><div class="spinner"></div><div class="loading-text">Fetching usage\u2026</div></div>';

  getPerplexityTab(function (err, tab) {
    if (err) { showError(err, false); return; }
    chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['refill-predictor.js', 'content.js'] }, function () {
      chrome.tabs.sendMessage(tab.id, { type: 'FETCH_USAGE' }, function (response) {
        refreshBtn.disabled = false;
        if (chrome.runtime.lastError || !response) { showError((chrome.runtime.lastError || {}).message || 'No response', true); return; }
        if (!response.ok) { showError(response.error, false); return; }

        lastRl = response.rateLimit; lastSt = response.settings;
        var nv = { pro: response.rateLimit.remaining_pro, research: response.rateLimit.remaining_research, labs: response.rateLimit.remaining_labs, upload: response.settings.upload_limit };
        RefillPredictor.recordSnapshotBatch(nv); RefillPredictor.saveLastValues(nv);
        dotEl.className = 'status-dot live'; tsEl.textContent = new Date().toLocaleTimeString();

        loadHourlyStats(nv, function (stats) {
          hrCache = stats;
          if (!graphKey) { bodyEl.innerHTML = renderBody(response.rateLimit, response.settings); bindCardClicks(); }
          startCountdown();
        });
      });
    });
  });
}

function showError(msg, needsTab) {
  dotEl.className = 'status-dot error'; refreshBtn.disabled = false; footerEl.style.display = 'none';
  bodyEl.innerHTML = '<div class="error-state"><div class="error-icon">\u26a0\ufe0f</div><div class="error-title">Could not load</div>'
    + '<div class="error-msg">' + (msg || 'Unknown error') + '</div>'
    + (needsTab ? '<div class="error-hint">Make sure you are logged into Perplexity.</div>' : '<div class="error-hint">Open perplexity.ai, log in, then refresh.</div>')
    + '</div>';
}

// ─── INIT ─────────────────────────────────────────────────────────────────────
expandBtn.innerHTML = expandSVG(false);
themeBtn.innerHTML  = themeIconSVG();
var prevValues = { pro: null, research: null, labs: null, upload: null };
RefillPredictor.getLastValues(function (sv) { prevValues = sv; fetchData(); });
