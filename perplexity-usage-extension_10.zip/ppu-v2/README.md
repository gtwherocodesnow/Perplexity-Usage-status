# Perplexity Usage — Chrome Extension
**Version 1.3 | Full Project Handoff README**

---

## What This Is

A Chrome extension that monitors a logged-in user's Perplexity.ai quota in real time. It injects a floating action button (FAB) into the Perplexity page and a toolbar popup, both showing remaining credits across 4 metrics with usage graphs and predictive refill countdowns.

---

## File Structure

```
ppu-v2/
├── manifest.json          MV3 manifest — permissions, icon, content script config
├── refill-predictor.js    Shared logic: recording, predicting, snapshot storage
├── content.js             Injected into perplexity.ai — FAB + inline panel
├── popup.js               Toolbar popup JS
├── popup.html             Toolbar popup UI (links refill-predictor.js then popup.js)
└── icons/
    ├── icon16.png
    ├── icon48.png
    └── icon128.png
```

---

## Architecture

### How data is fetched

Both `content.js` and `popup.js` call two Perplexity REST endpoints using `credentials: 'include'` (the user's own session cookies — no auth token stored in code):

| Endpoint | Fields used |
|---|---|
| `GET /rest/rate-limit/all` | `remaining_pro`, `remaining_research`, `remaining_labs` |
| `GET /rest/user/settings` | `upload_limit` |

The popup uses `chrome.scripting.executeScript` to inject both scripts into a Perplexity tab, then `chrome.tabs.sendMessage` with `{ type: 'FETCH_USAGE' }`. The content script's message listener does the actual fetch and responds `{ ok, rateLimit, settings }`.

### Auto-refresh

Both views auto-refresh every 60 seconds via `setInterval`. A live countdown bar is shown in the footer.

---

## Storage Schema (`chrome.storage.local`)

All data persists across extension reloads. The 3 storage keys are:

### `pu_refill_history`
```json
{
  "pro":      [{ "ts": 1700000000000, "delta": 150 }, ...],
  "research": [...],
  "labs":     [...],
  "upload":   [...]
}
```
Only written when a value **increases** (a refill event). Max 40 events per metric. Events older than 7 days are excluded from calculations.

### `pu_last_values`
```json
{ "pro": 141, "research": 8, "labs": 25, "upload": 16 }
```
Saved after every fetch so that `prevValues` is correct even after the popup closes and reopens, or the page reloads.

### `pu_snapshots`
```json
{
  "pro":      [{ "ts": 1700000000000, "val": 141 }, ...],
  "research": [...],
  "labs":     [...],
  "upload":   [...]
}
```
Written on **every fetch** regardless of whether values changed. Max 120 snapshots per metric (~2h at 60s interval). Used to render the usage graph when a card is clicked.

---

## RefillPredictor API (`refill-predictor.js`)

Exported as `window.RefillPredictor`:

| Method | Description |
|---|---|
| `recordBatch(oldValues, newValues)` | Atomic write — records refill events for ALL metrics in one storage read/write. Prevents race conditions from 4 separate writes. |
| `recordSnapshotBatch(values)` | Records a time-series snapshot of current values for graphing. |
| `getSnapshots(key, callback)` | Retrieves snapshot array for a given metric key. |
| `predict(key, callback)` | Calculates weighted rolling average of inter-refill gaps. Returns `{status, predicted, avgInterval, confidence, events, msUntil}`. |
| `saveLastValues(values)` | Persists current values so popup re-opens with correct baseline. |
| `getLastValues(callback)` | Loads persisted last values. Called before first fetch in both content.js and popup.js. |
| `label(pred)` | Returns display string e.g. `"+1 in 4h 23m"` or `"learning (2/4)"`. |
| `formatMs(ms)` | Formats milliseconds as `"4h 23m"`, `"12m 5s"`, `"any moment"`. |
| `clear()` | Removes all 3 storage keys. For debugging only. |

### Prediction Algorithm

1. Filter events to those within 7 days
2. Compute gaps between consecutive refill timestamps
3. Apply **weighted rolling average** — gap at index `j` has weight `j+1` (more recent = higher weight)
4. Predict next refill = `lastRefillTimestamp + avgInterval`
5. **Confidence** via coefficient of variation (CV = stddev/mean): `< 0.25` → high, `< 0.55` → medium, else low. Low confidence adds a `~` prefix.
6. Requires minimum 4 events before showing predictions.

---

## UI — content.js (FAB + inline panel)

- **FAB** fixed at `bottom:24px right:24px`, 40px circle. Icon is a bar-chart SVG.
- FAB border/glow updates based on worst metric: green normal → amber (≤10) → red (≤3).
- **Keyboard shortcut**: `Alt+U` toggles panel. `Escape` closes graph view or panel.
- **Panel** (306px wide) appears above FAB at `bottom:72px`.
- **Card grid**: 2×2, clicking any card enters **Graph View** for that metric.
- **Graph view**: shows SVG line chart rendered from snapshot history, current value, refill prediction, and (for Pro) usage % bar.
- **Pro card** has an extra progress bar showing `% used` of a hardcoded max of `PRO_MAX = 200`.

---

## UI — popup.js + popup.html (toolbar popup)

- 320px wide popup.
- Same card grid with click-to-graph functionality.
- Pro card shows usage % bar.
- Countdown bar + "Open Perplexity ↗" button in footer.

---

## Bugs Fixed (history)

| Version | Bug | Fix |
|---|---|---|
| 1.1 | Race condition: 4 individual `record()` calls each did read→write, losing 3 out of 4 updates | Replaced with `recordBatch()` — single atomic read→update all→write |
| 1.1 | Broken emoji escapes: `'\U0001F52C'` rendered as literal text | Replaced with actual UTF-8 emoji characters |
| 1.1 | `prevValues` reset to null every popup open/close | Persist via `pu_last_values` storage key, load before first fetch |
| 1.1 | Label said "refills in" implying full refill | Changed to "+1 in" |
| 1.1 | Stale events from days ago distorting average | Added 7-day cutoff filter before calculation |
| 1.2 | No snapshots stored, so no graph data | Added `recordSnapshotBatch()` and `pu_snapshots` key |
| 1.3 | `_pu_gv_val` in graph view had no color styling | Added inline `style="color:..."` using `accentColor()` |
| 1.3 | Redundant val assignment in `showGraphView` | Cleaned up to single `if/else if` chain |

---

## How to Update Without Losing Training Data

```
1. Make your changes to the source files in the ppu-v2/ folder
2. Go to chrome://extensions
3. Find "Perplexity Usage" in the list
4. Click the circular ↻ refresh icon on the extension card
5. Done — chrome.storage.local is NOT touched by extension reloads
```

**Storage is only lost if you:**
- Click "Remove" and reinstall from scratch
- Call `RefillPredictor.clear()` in the console
- The user manually clears browser/extension data in Chrome settings

---

## Known Limitations / Future Work

- **PRO_MAX = 200** is hardcoded. If Perplexity changes the limit it needs updating manually. Consider detecting max from an API response if one becomes available.
- **Upload limit** graph is less useful since it doesn't deplete like other quotas.
- **Multi-account** not supported — extension reads whoever's cookies are active in the browser.
- **Snapshot window** is 120 entries (~2h). A longer history option would improve graph usefulness.
- **Low quota alerts** (browser notifications when credits drop below threshold) not yet implemented — would require a background service worker.
- **Color-coded FAB** is set at panel open via `getLastValues`, so it reflects the last known state, not necessarily real-time.

---

## GitHub

Repo: `https://github.com/gtwherocodesnow/Perplexity-Usage-status`  
Landing page: `https://gtwherocodesnow.github.io/Perplexity-Usage-status`

---

*Last updated: v1.3 — graph view, Pro % bar, UI refresh, FAB status color, keyboard shortcut.*
