// refill-predictor.js — shared by content.js and popup.js
var RefillPredictor = (function () {

  var LASTVALS_KEY  = 'pu_last_values';   // { pro: 141, research: 8, ... }
  var SNAPSHOTS_KEY = 'pu_snapshots';     // { pro: [{ts,val},...], ... }
  var MAX_SNAPSHOTS = 1500;               // ~25h at 60s interval
  var MAX_SNAP_AGE  = 25 * 60 * 60 * 1000; // 25 hours

  // ─── RECORD SNAPSHOTS ──────────────────────────────────────────────────────
  // Stores a time-series snapshot of all values for graphing + /hr stat.
  // Called on every fetch regardless of whether values changed.
  function recordSnapshotBatch(values) {
    if (!values) return;
    chrome.storage.local.get(SNAPSHOTS_KEY, function (data) {
      var snapshots = data[SNAPSHOTS_KEY] || {};
      var now       = Date.now();
      var keys      = Object.keys(values);
      for (var i = 0; i < keys.length; i++) {
        var key = keys[i];
        var val = values[key];
        if (val == null) continue;
        if (!snapshots[key]) snapshots[key] = [];
        snapshots[key].push({ ts: now, val: val });
        // prune by age first, then by count
        var agecut = now - MAX_SNAP_AGE;
        snapshots[key] = snapshots[key].filter(function(s){ return s.ts >= agecut; });
        if (snapshots[key].length > MAX_SNAPSHOTS) snapshots[key] = snapshots[key].slice(-MAX_SNAPSHOTS);
      }
      var obj = {};
      obj[SNAPSHOTS_KEY] = snapshots;
      chrome.storage.local.set(obj);
    });
  }

  // ─── GET SNAPSHOTS ─────────────────────────────────────────────────────────
  function getSnapshots(key, callback) {
    chrome.storage.local.get(SNAPSHOTS_KEY, function (data) {
      callback(((data[SNAPSHOTS_KEY] || {})[key]) || []);
    });
  }

  // ─── PERSIST LAST KNOWN VALUES ─────────────────────────────────────────────
  function saveLastValues(values) {
    var obj = {};
    obj[LASTVALS_KEY] = values;
    chrome.storage.local.set(obj);
  }

  function getLastValues(callback) {
    chrome.storage.local.get(LASTVALS_KEY, function (data) {
      callback(data[LASTVALS_KEY] || { pro: null, research: null, labs: null, upload: null });
    });
  }

  // ─── CLEAR ALL DATA ────────────────────────────────────────────────────────
  function clear() {
    chrome.storage.local.remove([LASTVALS_KEY, SNAPSHOTS_KEY]);
  }

  return {
    recordSnapshotBatch: recordSnapshotBatch,
    getSnapshots:        getSnapshots,
    saveLastValues:      saveLastValues,
    getLastValues:       getLastValues,
    clear:               clear
  };
})();
