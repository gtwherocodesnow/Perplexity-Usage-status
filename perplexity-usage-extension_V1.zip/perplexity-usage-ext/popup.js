// popup.js

var REFRESH_INTERVAL = 60; // seconds
var countdownVal = REFRESH_INTERVAL;
var countdownTimer = null;
var lastData = null;

var dotEl       = document.getElementById('dot');
var tsEl        = document.getElementById('ts');
var bodyEl      = document.getElementById('body');
var footerEl    = document.getElementById('footer');
var refreshBtn  = document.getElementById('refresh-btn');
var countText   = document.getElementById('countdown-text');
var countBar    = document.getElementById('countdown-bar');
var openBtn     = document.getElementById('open-perplexity');

refreshBtn.addEventListener('click', function() { fetchData(); });
openBtn.addEventListener('click', function() {
  chrome.tabs.create({ url: 'https://www.perplexity.ai' });
});

// ── Colour helper ──
function colForValue(val, max) {
  if (!max) return '#34d9b3';
  var pct = (max - val) / max * 100; // % used
  return pct >= 85 ? '#f87171' : pct >= 60 ? '#fbbf24' : '#34d9b3';
}

// ── Render cards ──
function renderCards(rl, st) {
  var fields = [
    { label: 'Pro',          icon: '⚡', val: rl['remaining_pro'],      max: null },
    { label: 'Pro Research', icon: '🔬', val: rl['remaining_research'],  max: null },
    { label: 'Labs',         icon: '🧪', val: rl['remaining_labs'],      max: null },
    { label: 'Upload Limit', icon: '📎', val: st['upload_limit'],        max: null }
  ];

  var html = '<div class="cards">';
  for (var i = 0; i < fields.length; i++) {
    var f = fields[i];
    var val = f.val;
    if (val == null) continue;
    var col = colForValue(val, f.max);
    html += '<div class="card">'
      + '<div class="card-top-bar" style="background:' + col + '"></div>'
      + '<div class="card-label">' + f.icon + '&nbsp;' + f.label + '</div>'
      + '<div class="card-value" style="color:' + col + '">' + val.toLocaleString() + '</div>'
      + '<div class="card-sub">remaining</div>'
      + '</div>';
  }
  html += '</div>';
  return html;
}

// ── Countdown ──
function startCountdown() {
  if (countdownTimer) clearInterval(countdownTimer);
  countdownVal = REFRESH_INTERVAL;
  footerEl.style.display = 'flex';

  countdownTimer = setInterval(function() {
    countdownVal--;
    var pct = (countdownVal / REFRESH_INTERVAL) * 100;
    countText.textContent = countdownVal + 's';
    countBar.style.width = pct + '%';

    if (countdownVal <= 0) {
      clearInterval(countdownTimer);
      fetchData();
    }
  }, 1000);
}

// ── Find or create a Perplexity tab ──
function getPerplexityTab(callback) {
  chrome.tabs.query({ url: 'https://www.perplexity.ai/*' }, function(tabs) {
    if (tabs && tabs.length > 0) {
      callback(null, tabs[0]);
    } else {
      // No perplexity tab open — create one in background
      chrome.tabs.create(
        { url: 'https://www.perplexity.ai', active: false },
        function(tab) {
          // Wait for the tab to finish loading before messaging it
          function onUpdated(tabId, info) {
            if (tabId === tab.id && info.status === 'complete') {
              chrome.tabs.onUpdated.removeListener(onUpdated);
              // Small extra delay for page JS to settle
              setTimeout(function() { callback(null, tab); }, 800);
            }
          }
          chrome.tabs.onUpdated.addListener(onUpdated);
        }
      );
    }
  });
}

// ── Main fetch ──
function fetchData() {
  if (countdownTimer) clearInterval(countdownTimer);
  refreshBtn.disabled = true;
  dotEl.className = 'status-dot';

  bodyEl.innerHTML = '<div class="loading"><div class="spinner"></div><div class="loading-text">Fetching usage…</div></div>';
  footerEl.style.display = 'none';

  getPerplexityTab(function(err, tab) {
    if (err) { showError(err, false); return; }

    // Inject content script first (safe to call even if already injected)
    chrome.scripting.executeScript(
      { target: { tabId: tab.id }, files: ['content.js'] },
      function() {
        if (chrome.runtime.lastError) {
          // Script injection failed — try messaging anyway in case it's already there
        }
        // Send message to content script
        chrome.tabs.sendMessage(tab.id, { type: 'FETCH_USAGE' }, function(response) {
          refreshBtn.disabled = false;

          if (chrome.runtime.lastError || !response) {
            showError(
              (chrome.runtime.lastError && chrome.runtime.lastError.message) || 'No response from page.',
              true
            );
            return;
          }

          if (!response.ok) {
            showError(response.error, false);
            return;
          }

          lastData = response;
          dotEl.className = 'status-dot live';
          tsEl.textContent = new Date().toLocaleTimeString();
          bodyEl.innerHTML = renderCards(response.rateLimit, response.settings);
          startCountdown();
        });
      }
    );
  });
}

// ── Error state ──
function showError(msg, needsTab) {
  dotEl.className = 'status-dot error';
  refreshBtn.disabled = false;
  footerEl.style.display = 'none';

  var hint = needsTab
    ? '<div class="error-hint">Make sure you\'re <strong>logged into Perplexity</strong>. The extension will open a background tab to fetch your data.</div>'
    : '<div class="error-hint">Try <strong>opening perplexity.ai</strong> in a tab and logging in, then click ↻ Refresh.</div>';

  bodyEl.innerHTML = '<div class="error-state">'
    + '<div class="error-icon">⚠️</div>'
    + '<div class="error-title">Could not load data</div>'
    + '<div class="error-msg">' + (msg || 'Unknown error') + '</div>'
    + hint
    + '</div>';
}

// ── Init ──
fetchData();
