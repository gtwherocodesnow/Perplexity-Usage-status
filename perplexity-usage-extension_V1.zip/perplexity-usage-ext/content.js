// content.js — injected into perplexity.ai
(function () {
  if (document.getElementById('_pu_fab')) return;

  var style = document.createElement('style');
  style.textContent = [
    '@keyframes _pu_in{from{opacity:0;transform:translateY(6px) scale(.98)}to{opacity:1;transform:translateY(0) scale(1)}}',
    '@keyframes _pu_spin{to{transform:rotate(360deg)}}',
    '@keyframes _pu_pulse{0%,100%{opacity:1}50%{opacity:.3}}',
    '@keyframes _pu_up{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:translateY(0)}}',

    /* FAB — matches Perplexity's circular icon buttons */
    '#_pu_fab{',
      'position:fixed;bottom:24px;right:24px;z-index:2147483647;',
      'width:42px;height:42px;border-radius:50%;border:none;cursor:pointer;',
      'background:#1a1a1a;',
      'box-shadow:0 2px 12px rgba(0,0,0,.4);',
      'display:flex;align-items:center;justify-content:center;',
      'transition:background .15s,box-shadow .15s;font-size:1rem;line-height:1;',
    '}',
    '#_pu_fab:hover{background:#222;box-shadow:0 4px 16px rgba(0,0,0,.5);}',
    '#_pu_fab._pu_on{background:#1e2a1e;box-shadow:0 2px 12px rgba(0,0,0,.4),0 0 0 1.5px rgba(52,211,153,.35);}',

    /* Panel */
    '#_pu_panel{',
      'position:fixed;bottom:76px;right:24px;z-index:2147483646;',
      'width:310px;',
      'background:#111111;',
      'border:1px solid rgba(255,255,255,.08);',
      'border-radius:16px;',
      'box-shadow:0 8px 40px rgba(0,0,0,.6);',
      'font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","Inter",sans-serif;',
      'overflow:hidden;',
      'animation:_pu_in .16s ease both;',
    '}',

    /* Header */
    '#_pu_ph{',
      'padding:14px 16px 12px;',
      'display:flex;justify-content:space-between;align-items:center;',
      'border-bottom:1px solid rgba(255,255,255,.06);',
    '}',
    '._pu_hrow{display:flex;align-items:center;gap:8px;}',
    '._pu_dot{width:6px;height:6px;border-radius:50%;background:#444;flex-shrink:0;transition:all .3s;}',
    '._pu_dot._live{background:#34d399;box-shadow:0 0 5px rgba(52,211,153,.5);animation:_pu_pulse 2.5s infinite;}',
    '._pu_dot._err{background:#f87171;}',
    '._pu_title{font-size:.88rem;font-weight:500;color:rgba(255,255,255,.9);letter-spacing:-.01em;}',
    '._pu_title em{font-style:normal;color:#34d399;}',
    '._pu_ts{font-size:.62rem;color:rgba(255,255,255,.3);font-variant-numeric:tabular-nums;}',

    /* Refresh button — matches Perplexity icon buttons */
    '._pu_rbtn{',
      'background:transparent;border:none;',
      'color:rgba(255,255,255,.35);',
      'width:28px;height:28px;border-radius:7px;',
      'display:flex;align-items:center;justify-content:center;',
      'cursor:pointer;font-size:.9rem;transition:all .15s;padding:0;',
    '}',
    '._pu_rbtn:hover{background:rgba(255,255,255,.06);color:rgba(255,255,255,.7);}',
    '._pu_rbtn:disabled{opacity:.3;cursor:not-allowed;}',

    /* Cards */
    '#_pu_pb{padding:12px 12px 12px;}',
    '._pu_grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;}',
    '._pu_card{',
      'background:#1a1a1a;',
      'border:1px solid rgba(255,255,255,.06);',
      'border-radius:12px;',
      'padding:13px 14px;',
      'position:relative;overflow:hidden;',
      'opacity:0;animation:_pu_up .25s ease both;',
      'transition:border-color .15s,background .15s;',
    '}',
    '._pu_card:hover{background:#1e1e1e;border-color:rgba(255,255,255,.1);}',
    '._pu_ctb{position:absolute;top:0;left:0;right:0;height:1.5px;}',

    /* Label row */
    '._pu_cl{',
      'font-size:.58rem;letter-spacing:.06em;text-transform:uppercase;',
      'color:rgba(255,255,255,.3);margin-bottom:8px;',
      'display:flex;align-items:center;gap:5px;',
    '}',
    '._pu_cl svg{opacity:.5;}',

    /* Value */
    '._pu_cv{font-size:1.85rem;font-weight:600;line-height:1;letter-spacing:-.03em;color:#fff;}',
    '._pu_cv._warn{color:#fbbf24;}',
    '._pu_cv._low{color:#f87171;}',
    '._pu_cs{font-size:.6rem;color:rgba(255,255,255,.25);margin-top:5px;}',

    /* Spinner */
    '._pu_sp{width:18px;height:18px;border:1.5px solid rgba(255,255,255,.1);border-top-color:rgba(255,255,255,.5);border-radius:50%;animation:_pu_spin .7s linear infinite;}',

    /* Footer */
    '#_pu_pf{',
      'padding:9px 16px 11px;',
      'border-top:1px solid rgba(255,255,255,.06);',
      'display:flex;align-items:center;justify-content:space-between;',
    '}',
    '._pu_crow{display:flex;align-items:center;gap:7px;}',
    '._pu_ctext{font-size:.6rem;color:rgba(255,255,255,.25);font-variant-numeric:tabular-nums;}',
    '._pu_ctrack{width:52px;height:1.5px;background:rgba(255,255,255,.08);border-radius:99px;overflow:hidden;}',
    '._pu_cfill{height:100%;background:rgba(255,255,255,.2);border-radius:99px;transition:width 1s linear;}',
    '._pu_alabel{font-size:.6rem;color:rgba(255,255,255,.2);}',
  ].join('');
  document.head.appendChild(style);

  // FAB icon — simple bar chart SVG matching Perplexity's icon style
  var fab = document.createElement('button');
  fab.id = '_pu_fab';
  fab.title = 'Usage';
  fab.innerHTML = '<svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">'
    + '<rect x="1" y="9" width="4" height="8" rx="1.5" fill="rgba(255,255,255,.75)"/>'
    + '<rect x="7" y="5" width="4" height="12" rx="1.5" fill="rgba(255,255,255,.75)"/>'
    + '<rect x="13" y="1" width="4" height="16" rx="1.5" fill="rgba(255,255,255,.75)"/>'
    + '</svg>';
  document.body.appendChild(fab);

  var panel = null;
  var open = false;
  var countTimer = null;
  var countVal = 60;

  function valColor(val) {
    if (val == null) return 'normal';
    if (val <= 3)  return 'low';
    if (val <= 10) return 'warn';
    return 'normal';
  }

  function accentColor(val) {
    if (val == null) return 'rgba(255,255,255,.15)';
    if (val <= 3)  return 'rgba(248,113,113,.6)';
    if (val <= 10) return 'rgba(251,191,36,.6)';
    return 'rgba(52,211,153,.5)';
  }

  // Small inline SVG icons matching Perplexity's style
  var icons = {
    pro:      '<svg width="10" height="10" viewBox="0 0 12 12" fill="currentColor"><path d="M6 1l1.4 3h3.2l-2.6 1.9.9 3L6 7.1 3.1 8.9l.9-3L1.4 4h3.2z"/></svg>',
    research: '<svg width="10" height="10" viewBox="0 0 12 12" fill="currentColor"><circle cx="5" cy="5" r="3.5" stroke="currentColor" stroke-width="1.5" fill="none"/><line x1="7.5" y1="7.5" x2="11" y2="11" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>',
    labs:     '<svg width="10" height="10" viewBox="0 0 12 12" fill="currentColor"><path d="M4.5 1v5L1.5 10.5h9L7.5 6V1" stroke="currentColor" stroke-width="1.5" fill="none" stroke-linecap="round" stroke-linejoin="round"/><line x1="3.5" y1="1" x2="8.5" y2="1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>',
    upload:   '<svg width="10" height="10" viewBox="0 0 12 12" fill="currentColor"><path d="M2 9.5h8M6 1.5v6M3.5 4L6 1.5 8.5 4" stroke="currentColor" stroke-width="1.5" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>'
  };

  function renderCards(rl, st) {
    var fields = [
      { icon: icons.pro,      label: 'Pro',          val: rl['remaining_pro'],      key: 'pro' },
      { icon: icons.research, label: 'Pro Research', val: rl['remaining_research'],  key: 'research' },
      { icon: icons.labs,     label: 'Labs',         val: rl['remaining_labs'],      key: 'labs' },
      { icon: icons.upload,   label: 'Upload Limit', val: st['upload_limit'],        key: 'upload' }
    ];
    var html = '<div class="_pu_grid">';
    for (var i = 0; i < fields.length; i++) {
      var f = fields[i];
      if (f.val == null) continue;
      var vc = valColor(f.val);
      var ac = accentColor(f.val);
      html += '<div class="_pu_card" style="animation-delay:' + (i * 45) + 'ms">'
        + '<div class="_pu_ctb" style="background:' + ac + '"></div>'
        + '<div class="_pu_cl">' + f.icon + f.label + '</div>'
        + '<div class="_pu_cv' + (vc !== 'normal' ? ' _' + vc : '') + '">' + f.val.toLocaleString() + '</div>'
        + '<div class="_pu_cs">remaining</div>'
        + '</div>';
    }
    return html + '</div>';
  }

  function startCountdown() {
    if (countTimer) clearInterval(countTimer);
    countVal = 60;
    syncCount();
    countTimer = setInterval(function () {
      countVal--;
      syncCount();
      if (countVal <= 0) { clearInterval(countTimer); doFetch(); }
    }, 1000);
  }

  function syncCount() {
    var t = document.getElementById('_pu_ctext');
    var b = document.getElementById('_pu_cfill');
    if (t) t.textContent = countVal + 's';
    if (b) b.style.width = (countVal / 60 * 100) + '%';
  }

  function doFetch() {
    var dot = document.getElementById('_pu_dot');
    var ts  = document.getElementById('_pu_ts');
    var pb  = document.getElementById('_pu_pb');
    var pf  = document.getElementById('_pu_pf');
    var rb  = document.getElementById('_pu_rbtn');
    if (!pb) return;
    if (rb)  rb.disabled = true;
    if (dot) dot.className = '_pu_dot';
    if (pf)  pf.style.display = 'none';
    pb.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;padding:24px 0;gap:10px;">'
      + '<div class="_pu_sp"></div>'
      + '<div style="font-size:.65rem;color:rgba(255,255,255,.25);">Fetching\u2026</div></div>';

    Promise.all([
      fetch('/rest/rate-limit/all', { credentials: 'include' })
        .then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); }),
      fetch('/rest/user/settings', { credentials: 'include' })
        .then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
    ]).then(function (res) {
      pb.innerHTML = renderCards(res[0], res[1]);
      if (dot) dot.className = '_pu_dot _live';
      if (ts)  ts.textContent = new Date().toLocaleTimeString();
      if (rb)  rb.disabled = false;
      if (pf)  pf.style.display = 'flex';
      startCountdown();
    }).catch(function (err) {
      pb.innerHTML = '<div style="text-align:center;padding:20px 0;">'
        + '<div style="font-size:.75rem;font-weight:500;color:rgba(248,113,113,.9);">Failed to load</div>'
        + '<div style="font-size:.62rem;color:rgba(255,255,255,.25);margin-top:4px;">' + err.message + '</div></div>';
      if (dot) dot.className = '_pu_dot _err';
      if (rb)  rb.disabled = false;
    });
  }

  function buildPanel() {
    var p = document.createElement('div');
    p.id = '_pu_panel';
    p.innerHTML = '<div id="_pu_ph">'
        + '<div class="_pu_hrow">'
          + '<div class="_pu_dot" id="_pu_dot"></div>'
          + '<div class="_pu_title">Perplexity <em>Usage</em></div>'
        + '</div>'
        + '<div class="_pu_hrow">'
          + '<span class="_pu_ts" id="_pu_ts"></span>'
          + '<button class="_pu_rbtn" id="_pu_rbtn" title="Refresh">'
            + '<svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">'
            + '<path d="M12.5 7A5.5 5.5 0 1 1 9.2 2.1"/>'
            + '<polyline points="9.5 1.5 9.2 4 11.7 4.3"/>'
            + '</svg>'
          + '</button>'
        + '</div>'
      + '</div>'
      + '<div id="_pu_pb"></div>'
      + '<div id="_pu_pf" style="display:none;">'
        + '<div class="_pu_crow">'
          + '<span class="_pu_ctext" id="_pu_ctext">60s</span>'
          + '<div class="_pu_ctrack"><div class="_pu_cfill" id="_pu_cfill" style="width:100%"></div></div>'
        + '</div>'
        + '<span class="_pu_alabel">auto-refresh</span>'
      + '</div>';
    return p;
  }

  function openPanel() {
    if (panel) panel.remove();
    panel = buildPanel();
    document.body.appendChild(panel);
    document.getElementById('_pu_rbtn').addEventListener('click', function () {
      if (countTimer) clearInterval(countTimer);
      doFetch();
    });
    doFetch();
  }

  function closePanel() {
    if (countTimer) clearInterval(countTimer);
    if (panel) { panel.remove(); panel = null; }
  }

  fab.addEventListener('click', function (e) {
    e.stopPropagation();
    open = !open;
    fab.classList.toggle('_pu_on', open);
    if (open) openPanel(); else closePanel();
  });

  document.addEventListener('click', function (e) {
    if (open && panel && !panel.contains(e.target) && e.target !== fab) {
      open = false;
      fab.classList.remove('_pu_on');
      closePanel();
    }
  }, true);

  // Message listener for popup compatibility
  chrome.runtime.onMessage.addListener(function (req, sender, sendResponse) {
    if (req.type !== 'FETCH_USAGE') return;
    Promise.all([
      fetch('/rest/rate-limit/all', { credentials: 'include' }).then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); }),
      fetch('/rest/user/settings',  { credentials: 'include' }).then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
    ]).then(function (res) { sendResponse({ ok: true, rateLimit: res[0], settings: res[1] }); })
      .catch(function (err) { sendResponse({ ok: false, error: err.message }); });
    return true;
  });

})();
